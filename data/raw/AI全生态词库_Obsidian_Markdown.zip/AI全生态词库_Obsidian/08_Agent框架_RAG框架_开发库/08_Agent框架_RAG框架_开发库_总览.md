# 08_Agent框架_RAG框架_开发库

- 词条数量：19
- 更新时间：2026-06-21
- 用法：先看表格总览，再在下方词条内记录教程、试用经验、接入步骤。

## 快速总览

| 原名 | 直译 | 常用中文名 | 类型 | 热度 | Stars | Forks | 开源 | 本地部署 | 适合Codex | 来源 |
|---|---|---|---|---|---:|---:|---|---|---|---|
| LangChain | 语言链 | LangChain | 开源项目 | SSS 超顶流 | 139784 | 23183 | 是 | 部分 | 是 | https://github.com/langchain-ai/langchain |
| LangGraph | 语言图 | LangGraph | 开源项目 | S 高热 | 35322 | 5924 | 是 | 部分 | 是 | https://github.com/langchain-ai/langgraph |
| Dify | 品牌名 | Dify | 开源项目/平台 | SSS 超顶流 | 145982 | 22959 | 是 | 是 | 是 | https://github.com/langgenius/dify |
| LlamaIndex | Llama索引 | LlamaIndex | 开源项目 | SS 顶流 | 50200 | 7600 | 是 | 部分 | 是 | https://github.com/run-llama/llama_index |
| CrewAI | 团队AI | CrewAI | 开源项目 | SS 顶流 | 54100 | 7600 | 是 | 部分 | 是 | https://github.com/crewAIInc/crewAI |
| Flowise | 流式智能 | Flowise | 开源项目 | SS 顶流 | 53800 | 24600 | 是 | 是 | 是 | https://github.com/FlowiseAI/Flowise |
| Langflow | 语言流 | Langflow | 开源项目/平台 | SSS 超顶流 | 150000 | 9300 | 是 | 是 | 是 | https://github.com/langflow-ai/langflow |
| AutoGen | 自动生成 | AutoGen | 开源项目 | SS 顶流 | 59100 | 8900 | 是 | 部分 | 部分 | https://github.com/microsoft/autogen |
| Semantic Kernel | 语义内核 | Semantic Kernel | 开源项目 | S 高热 | 28200 | 4700 | 是 | 部分 | 是 | https://github.com/microsoft/semantic-kernel |
| OpenAI Agents SDK | OpenAI智能体SDK | OpenAI Agents SDK | 开源项目/SDK | A 中高热 | 11000 | 1800 | 是 | 部分 | 是 | https://github.com/openai/openai-agents-python |
| Google ADK | Google智能体开发套件 | Google ADK | SDK/框架 | B 垂直热 | 8000 | 900 | 是 | 部分 | 部分 | https://github.com/google/adk-python |
| Pydantic AI | Pydantic AI | Pydantic AI | 开源项目 | A 中高热 | 11000 | 900 | 是 | 部分 | 是 | https://github.com/pydantic/pydantic-ai |
| Haystack | 干草堆 | Haystack | 开源项目 | S 高热 | 23000 | 4200 | 是 | 部分 | 是 | https://github.com/deepset-ai/haystack |
| DSPy | DSPy | DSPy | 开源项目 | S 高热 | 28000 | 2200 | 是 | 部分 | 部分 | https://github.com/stanfordnlp/dspy |
| Vercel AI SDK | Vercel AI软件开发套件 | Vercel AI SDK | 开源项目/SDK | A 中高热 | 17000 | 2700 | 是 | 部分 | 是 | https://github.com/vercel/ai |
| LiteLLM | 轻量LLM | LiteLLM | 开源项目 | S 高热 | 30000 | 4000 | 是 | 是 | 是 | https://github.com/BerriAI/litellm |
| OpenRouter | 开放路由器 | OpenRouter | 平台 |  |  |  | 否 | 否 | 是 | https://openrouter.ai/ |
| Portkey | 端口钥匙 | Portkey | 平台/SDK |  |  |  | 部分 | 部分 | 是 | https://portkey.ai/ |
| Mastra | 品牌名 | Mastra | 开源项目 | A 中高热 | 12000 | 900 | 是 | 部分 | 是 | https://github.com/mastra-ai/mastra |

## 详细词条

## LangChain

> 构建Agent、RAG、工具调用、模型编排的核心框架。

| 字段 | 内容 |
|---|---|
| 原名 | LangChain |
| 直译 | 语言链 |
| 常用中文名 | LangChain |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/langchain-ai/langchain |
| 代表GitHub仓库 | langchain-ai/langchain |
| GitHub Stars(约) | 139784 |
| Forks(约) | 23183 |
| 热度等级 | SSS 超顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/langchain-ai/langchain |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## LangGraph

> 有状态、长任务、多Agent、可恢复的Agent编排框架。

| 字段 | 内容 |
|---|---|
| 原名 | LangGraph |
| 直译 | 语言图 |
| 常用中文名 | LangGraph |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/langchain-ai/langgraph |
| 代表GitHub仓库 | langchain-ai/langgraph |
| GitHub Stars(约) | 35322 |
| Forks(约) | 5924 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/langchain-ai/langgraph |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Dify

> 生产级Agentic workflow、RAG、AI应用平台。

| 字段 | 内容 |
|---|---|
| 原名 | Dify |
| 直译 | 品牌名 |
| 常用中文名 | Dify |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目/平台 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/langgenius/dify |
| 代表GitHub仓库 | langgenius/dify |
| GitHub Stars(约) | 145982 |
| Forks(约) | 22959 |
| 热度等级 | SSS 超顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/langgenius/dify |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## LlamaIndex

> 文档、数据库、RAG、知识库接入LLM的框架。

| 字段 | 内容 |
|---|---|
| 原名 | LlamaIndex |
| 直译 | Llama索引 |
| 常用中文名 | LlamaIndex |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/run-llama/llama_index |
| 代表GitHub仓库 | run-llama/llama_index |
| GitHub Stars(约) | 50200 |
| Forks(约) | 7600 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/run-llama/llama_index |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## CrewAI

> 多角色Agent协作与自动化框架。

| 字段 | 内容 |
|---|---|
| 原名 | CrewAI |
| 直译 | 团队AI |
| 常用中文名 | CrewAI |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/crewAIInc/crewAI |
| 代表GitHub仓库 | crewAIInc/crewAI |
| GitHub Stars(约) | 54100 |
| Forks(约) | 7600 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/crewAIInc/crewAI |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Flowise

> 拖拽式构建LLM应用、Agent和RAG流程。

| 字段 | 内容 |
|---|---|
| 原名 | Flowise |
| 直译 | 流式智能 |
| 常用中文名 | Flowise |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/FlowiseAI/Flowise |
| 代表GitHub仓库 | FlowiseAI/Flowise |
| GitHub Stars(约) | 53800 |
| Forks(约) | 24600 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/FlowiseAI/Flowise |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Langflow

> 可视化构建AI Agent、RAG应用和MCP Server。

| 字段 | 内容 |
|---|---|
| 原名 | Langflow |
| 直译 | 语言流 |
| 常用中文名 | Langflow |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目/平台 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/langflow-ai/langflow |
| 代表GitHub仓库 | langflow-ai/langflow |
| GitHub Stars(约) | 150000 |
| Forks(约) | 9300 |
| 热度等级 | SSS 超顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/langflow-ai/langflow |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## AutoGen

> 微软多Agent对话与协作框架，当前需注意维护模式。

| 字段 | 内容 |
|---|---|
| 原名 | AutoGen |
| 直译 | 自动生成 |
| 常用中文名 | AutoGen |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/microsoft/autogen |
| 代表GitHub仓库 | microsoft/autogen |
| GitHub Stars(约) | 59100 |
| Forks(约) | 8900 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 部分 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/microsoft/autogen |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Semantic Kernel

> 微软AI编排SDK，适合企业.NET/Python/Java生态。

| 字段 | 内容 |
|---|---|
| 原名 | Semantic Kernel |
| 直译 | 语义内核 |
| 常用中文名 | Semantic Kernel |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/microsoft/semantic-kernel |
| 代表GitHub仓库 | microsoft/semantic-kernel |
| GitHub Stars(约) | 28200 |
| Forks(约) | 4700 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 部分 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/microsoft/semantic-kernel |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## OpenAI Agents SDK

> OpenAI官方Agent开发SDK，支持工具、交接、护栏、追踪。

| 字段 | 内容 |
|---|---|
| 原名 | OpenAI Agents SDK |
| 直译 | OpenAI智能体SDK |
| 常用中文名 | OpenAI Agents SDK |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目/SDK |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/openai/openai-agents-python |
| 代表GitHub仓库 | openai/openai-agents-python |
| GitHub Stars(约) | 11000 |
| Forks(约) | 1800 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/openai/openai-agents-python |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Google ADK

> Google Agent Development Kit，用于开发Agent应用。

| 字段 | 内容 |
|---|---|
| 原名 | Google ADK |
| 直译 | Google智能体开发套件 |
| 常用中文名 | Google ADK |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | SDK/框架 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/google/adk-python |
| 代表GitHub仓库 | google/adk-python |
| GitHub Stars(约) | 8000 |
| Forks(约) | 900 |
| 热度等级 | B 垂直热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/google/adk-python |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Pydantic AI

> 类型安全Python Agent框架，适合结构化输出。

| 字段 | 内容 |
|---|---|
| 原名 | Pydantic AI |
| 直译 | Pydantic AI |
| 常用中文名 | Pydantic AI |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/pydantic/pydantic-ai |
| 代表GitHub仓库 | pydantic/pydantic-ai |
| GitHub Stars(约) | 11000 |
| Forks(约) | 900 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/pydantic/pydantic-ai |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Haystack

> RAG、搜索、问答和LLM应用框架。

| 字段 | 内容 |
|---|---|
| 原名 | Haystack |
| 直译 | 干草堆 |
| 常用中文名 | Haystack |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/deepset-ai/haystack |
| 代表GitHub仓库 | deepset-ai/haystack |
| GitHub Stars(约) | 23000 |
| Forks(约) | 4200 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/deepset-ai/haystack |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## DSPy

> 可优化LLM pipeline的编程框架。

| 字段 | 内容 |
|---|---|
| 原名 | DSPy |
| 直译 | DSPy |
| 常用中文名 | DSPy |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/stanfordnlp/dspy |
| 代表GitHub仓库 | stanfordnlp/dspy |
| GitHub Stars(约) | 28000 |
| Forks(约) | 2200 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/stanfordnlp/dspy |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Vercel AI SDK

> 前端/全栈AI应用开发SDK，适合Next.js和流式聊天。

| 字段 | 内容 |
|---|---|
| 原名 | Vercel AI SDK |
| 直译 | Vercel AI软件开发套件 |
| 常用中文名 | Vercel AI SDK |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目/SDK |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/vercel/ai |
| 代表GitHub仓库 | vercel/ai |
| GitHub Stars(约) | 17000 |
| Forks(约) | 2700 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 部分 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/vercel/ai |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## LiteLLM

> 多模型统一调用网关，兼容OpenAI接口。

| 字段 | 内容 |
|---|---|
| 原名 | LiteLLM |
| 直译 | 轻量LLM |
| 常用中文名 | LiteLLM |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/BerriAI/litellm |
| 代表GitHub仓库 | BerriAI/litellm |
| GitHub Stars(约) | 30000 |
| Forks(约) | 4000 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/BerriAI/litellm |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## OpenRouter

> 多模型路由平台，统一接入多家模型。

| 字段 | 内容 |
|---|---|
| 原名 | OpenRouter |
| 直译 | 开放路由器 |
| 常用中文名 | OpenRouter |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 平台 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://openrouter.ai/ |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://openrouter.ai/ |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Portkey

> LLM网关、路由、观测、成本控制平台。

| 字段 | 内容 |
|---|---|
| 原名 | Portkey |
| 直译 | 端口钥匙 |
| 常用中文名 | Portkey |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 平台/SDK |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://portkey.ai/ |
| 是否开源 | 部分 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://portkey.ai/ |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Mastra

> TypeScript Agent框架。

| 字段 | 内容 |
|---|---|
| 原名 | Mastra |
| 直译 | 品牌名 |
| 常用中文名 | Mastra |
| 类别 | 08_Agent框架_RAG框架_开发库 |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 用于搭建可部署的Agent、RAG、工作流和AI应用。 |
| 代表平台/官网 | https://github.com/mastra-ai/mastra |
| 代表GitHub仓库 | mastra-ai/mastra |
| GitHub Stars(约) | 12000 |
| Forks(约) | 900 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 部分 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 框架,Agent,RAG,开发库 |
| 风险/备注 | 框架更新快，项目选型需验证文档与维护状态。 |
| 数据来源URL | https://github.com/mastra-ai/mastra |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：
