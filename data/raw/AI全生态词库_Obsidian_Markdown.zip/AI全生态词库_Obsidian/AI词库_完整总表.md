# AI词库_完整总表

- 总词条数：458
- 更新时间：2026-06-21

| 类别 | 原名 | 直译 | 常用中文名 | 类型 | 解释 | 热度 | Stars | Forks | 开源 | 本地部署 | 适合Codex | 来源 |
|---|---|---|---|---|---|---|---:|---:|---|---|---|---|
| 01_AI模型基础 | AI | Artificial Intelligence 直译：人工智能 | 人工智能 | 术语 | 让机器完成理解、生成、推理、决策、执行等任务的技术总称。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | GenAI | Generative AI 直译：生成式人工智能 | 生成式AI | 术语 | 能生成文字、图片、代码、音频、视频等内容的AI。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | LLM | Large Language Model 直译：大型语言模型 | 大语言模型 | 术语 | 通过海量文本/代码训练出来的语言模型。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | MLLM/LMM | Multimodal/Large Multimodal Model 直译：多模态大模型 | 多模态大模型 | 术语 | 能同时处理文字、图片、音频、视频、屏幕等信息的模型。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Foundation Model | 基础模型 | 基础模型 | 术语 | 大规模预训练后可适配多种任务的模型。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Frontier Model | 前沿模型 | 前沿模型 | 术语 | 当前能力位于行业前沿的一批模型。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Reasoning Model | 推理模型 | 推理模型 | 术语 | 更擅长复杂规划、数学、代码、多步推理的模型。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Instruct Model | 指令模型 | 指令微调模型 | 术语 | 专门优化过听指令、完成任务能力的模型。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Base Model | 基座模型 | 基座模型 | 术语 | 未经完整指令对齐的原始模型。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Vision Model | 视觉模型 | 视觉模型 | 术语 | 专门理解图片、截图、图表和视觉内容的模型。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Audio Model | 音频模型 | 音频模型 | 术语 | 处理语音识别、语音合成、音频理解的模型。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Video Model | 视频模型 | 视频模型 | 术语 | 理解或生成视频内容的模型。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Diffusion Model | 扩散模型 | 扩散模型 | 术语 | 常用于图像/视频生成的模型架构。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Transformer | 变换器 | Transformer架构 | 术语 | 当前大模型主流架构。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | MoE | Mixture of Experts 直译：专家混合 | 混合专家模型 | 术语 | 多个专家子模型按任务动态激活，降低推理成本。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Dense Model | 稠密模型 | 稠密模型 | 术语 | 推理时基本激活全部参数的模型。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | SLM | Small Language Model 直译：小语言模型 | 小语言模型 | 术语 | 参数更小、成本更低、适合本地/边缘部署的语言模型。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Open-weight Model | 开放权重模型 | 开放权重模型 | 术语 | 可以下载模型权重运行，但不一定完整开源。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Open-source Model | 开源模型 | 开源模型 | 术语 | 通常包含代码、权重或训练细节，允许社区使用和改造。 |  |  |  |  |  |  |  |
| 01_AI模型基础 | Closed Model | 闭源模型 | 闭源模型 | 术语 | 只能通过API或产品平台使用，权重不公开。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Token | 令牌/词元 | Token | 术语 | 模型计费和上下文计算的基本单位。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Context Window | 上下文窗口 | 上下文窗口 | 术语 | 模型一次能读取的最大内容量。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Prompt | 提示/提示词 | 提示词 | 术语 | 你发给AI的任务说明。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | System Prompt | 系统提示 | 系统提示词 | 术语 | 规定AI角色、边界、规则的高优先级指令。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Developer Prompt | 开发者提示 | 开发者提示词 | 术语 | 应用/产品层给模型的规则。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Prompt Engineering | 提示工程 | 提示词工程 | 术语 | 设计更有效的提示词。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Context Engineering | 上下文工程 | 上下文工程 | 术语 | 组织文件、规则、背景、示例，让AI在正确上下文里工作。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Temperature | 温度 | 随机性参数 | 术语 | 控制模型输出的随机程度。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Top-p | 最高概率质量 | Top-p采样 | 术语 | 控制模型从多大概率范围内选词。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Max Tokens | 最大令牌数 | 最大输出长度 | 术语 | 限制模型最大输出长度。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Structured Output | 结构化输出 | 结构化输出 | 术语 | 让模型按JSON、表格、Schema等格式输出。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | JSON Mode | JSON模式 | JSON模式 | 术语 | 强制模型输出JSON。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Schema | 模式/结构 | 结构规范 | 术语 | 规定数据字段和类型。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | JSON Schema | JSON结构规范 | JSON Schema | 术语 | 常用于工具调用和结构化输出的参数约束。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Streaming | 流式传输 | 流式输出 | 术语 | 边生成边显示。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Latency | 延迟 | 延迟 | 术语 | 请求到响应的等待时间。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Throughput | 吞吐量 | 吞吐量 | 术语 | 单位时间处理请求或token的能力。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Rate Limit | 速率限制 | 速率限制 | 术语 | 单位时间最大请求量。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Quota | 配额 | 配额 | 术语 | 账号或套餐可用量。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Token Budget | 令牌预算 | Token预算 | 术语 | 限制每次任务消耗，控制成本。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Prompt Cache | 提示缓存 | 提示词缓存 | 术语 | 缓存重复上下文以降低成本和延迟。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | KV Cache | 键值缓存 | 推理缓存 | 术语 | 保存推理中间状态以加速生成。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Batching | 批处理 | 批处理 | 术语 | 合并多个请求提高吞吐。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Hallucination | 幻觉 | AI幻觉 | 术语 | AI编造不存在的事实、链接或API。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Grounding | 落地/依据化 | 依据化 | 术语 | 让回答基于可靠资料来源。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Citation | 引用 | 引用来源 | 术语 | 回答时标注资料出处。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Eval | 评估 | 评测 | 术语 | 用任务集测试模型/应用效果。 |  |  |  |  |  |  |  |
| 02_模型参数与Token | Benchmark | 基准测试 | 基准测试 | 术语 | 标准化评测集合或榜单。 |  |  |  |  |  |  |  |
| 03_主流模型家族 | GPT | 生成式预训练变换器 | GPT | 模型/平台 | OpenAI模型家族。 | 国际顶流 |  |  | 部分 | 部分 | 部分 | https://openai.com/ |
| 03_主流模型家族 | Claude | 克劳德 | Claude | 模型/平台 | Anthropic模型家族，长文本、代码、文档能力强。 | 国际顶流 |  |  | 部分 | 部分 | 部分 | https://www.anthropic.com/ |
| 03_主流模型家族 | Gemini | 双子座 | Gemini | 模型/平台 | Google模型家族，多模态和生态集成强。 | 国际顶流 |  |  | 部分 | 部分 | 部分 | https://gemini.google.com/ |
| 03_主流模型家族 | Grok | 格罗克 | Grok | 模型/平台 | xAI模型家族。 | 国际高热 |  |  | 部分 | 部分 | 部分 | https://x.ai/ |
| 03_主流模型家族 | DeepSeek | 深度探索 | DeepSeek | 模型/平台 | 中文/代码/推理/本地部署生态常见模型家族。 | 国内顶流 |  |  | 部分 | 部分 | 部分 | https://www.deepseek.com/ |
| 03_主流模型家族 | Qwen | 通义千问 | 通义千问/Qwen | 模型/平台 | 阿里开源和商业模型家族，中文和本地部署生态强。 | 国内顶流 |  |  | 部分 | 部分 | 部分 | https://qwenlm.github.io/ |
| 03_主流模型家族 | Llama | 美洲驼 | Llama | 模型/平台 | Meta开源模型家族，全球本地部署基础模型之一。 | 国际顶流 |  |  | 部分 | 部分 | 部分 | https://www.llama.com/ |
| 03_主流模型家族 | Mistral | 西北风 | Mistral | 模型/平台 | 法国Mistral AI模型家族，开源和商业模型并行。 | 国际高热 |  |  | 部分 | 部分 | 部分 | https://mistral.ai/ |
| 03_主流模型家族 | Gemma | 宝石 | Gemma | 模型/平台 | Google开源轻量模型系列。 | 国际高热 |  |  | 部分 | 部分 | 部分 | https://ai.google.dev/gemma |
| 03_主流模型家族 | Phi | 希腊字母Phi | Phi | 模型/平台 | Microsoft小模型系列，适合边缘/低成本场景。 | 国际高热 |  |  | 部分 | 部分 | 部分 | https://azure.microsoft.com/ |
| 03_主流模型家族 | GLM | 通用语言模型 | 智谱GLM | 模型/平台 | 智谱模型系列。 | 国内高热 |  |  | 部分 | 部分 | 部分 | https://www.zhipuai.cn/ |
| 03_主流模型家族 | Kimi | 品牌名 | Kimi/Moonshot | 模型/平台 | 月之暗面模型和应用。 | 国内高热 |  |  | 部分 | 部分 | 部分 | https://www.kimi.com/ |
| 03_主流模型家族 | Doubao | 豆包 | 豆包 | 模型/平台 | 字节模型和应用生态。 | 国内顶流 |  |  | 部分 | 部分 | 部分 | https://www.doubao.com/ |
| 03_主流模型家族 | Hunyuan | 混元 | 腾讯混元 | 模型/平台 | 腾讯模型家族。 | 国内高热 |  |  | 部分 | 部分 | 部分 | https://hunyuan.tencent.com/ |
| 03_主流模型家族 | ERNIE | 文心 | 文心大模型 | 模型/平台 | 百度文心模型系列。 | 国内高热 |  |  | 部分 | 部分 | 部分 | https://yiyan.baidu.com/ |
| 03_主流模型家族 | Command R | 命令R | Command R | 模型/平台 | Cohere模型，企业RAG/检索增强场景常见。 | 国际中高热 |  |  | 部分 | 部分 | 部分 | https://cohere.com/ |
| 03_主流模型家族 | Nous Hermes | Nous赫尔墨斯 | Hermes模型 | 模型/平台 | Nous Research开源模型家族，常见于本地模型生态。 | 国际中高热 |  |  | 部分 | 部分 | 部分 | https://nousresearch.com/ |
| 04_Agent智能体 | Agent | 代理/智能体 | 智能体 | 术语 | 能根据目标规划、调用工具并执行任务的AI系统。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | AI Agent | AI智能体 | AI智能体 | 术语 | 比聊天机器人更进一步，能执行动作和多步任务。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Agentic AI | 智能体式AI | Agentic AI | 术语 | 从回答问题转向完成任务的AI形态。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Autonomous Agent | 自主智能体 | 自主Agent | 术语 | 人给目标，Agent自己拆解和执行。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Semi-autonomous Agent | 半自主智能体 | 半自主Agent | 术语 | 关键动作需要人工审批的Agent。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Multi-Agent | 多智能体 | 多Agent | 术语 | 多个AI角色分工协作。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Supervisor Agent | 主管智能体 | 主管Agent | 术语 | 负责规划、分配、协调和验收。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Worker Agent | 工人智能体 | 执行Agent | 术语 | 负责具体执行子任务。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Reviewer Agent | 审查智能体 | 审查Agent | 术语 | 检查代码、文档、结果质量。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Planner Agent | 规划智能体 | 规划Agent | 术语 | 把目标拆解成可执行步骤。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Executor Agent | 执行智能体 | 执行Agent | 术语 | 调用工具、跑命令、改文件。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Critic Agent | 批判智能体 | 质检Agent | 术语 | 找问题、提改进建议。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Research Agent | 研究智能体 | 调研Agent | 术语 | 查资料、整合信息、写报告。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Coding Agent | 编程智能体 | 编程Agent | 术语 | 读仓库、改代码、跑测试。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Browser Agent | 浏览器智能体 | 网页Agent | 术语 | 操作浏览器完成网页任务。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Data Agent | 数据智能体 | 数据Agent | 术语 | 分析数据、生成图表和报告。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Design Agent | 设计智能体 | 设计Agent | 术语 | 生成视觉、UI、海报、品牌资产。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Agent Loop | 智能体循环 | Agent循环 | 术语 | 计划→工具→观察→修正的循环。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | ReAct | Reason+Act 直译：推理+行动 | ReAct模式 | 术语 | 边推理边调用工具。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Plan-and-Execute | 计划并执行 | 先规划后执行 | 术语 | 先生成计划，再分步执行。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Reflection | 反思 | 反思机制 | 术语 | 执行后自查和迭代。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Self-Healing | 自我修复 | 自修复 | 术语 | 失败后自动换路径、重试、修复。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Tool Use | 工具使用 | 工具使用 | 术语 | AI调用搜索、终端、浏览器、数据库等工具。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Function Calling | 函数调用 | 函数调用 | 术语 | 模型按结构化参数调用函数/API。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Tool Calling | 工具调用 | 工具调用 | 术语 | 更广义的外部工具调用能力。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Observation | 观察 | 观察结果 | 术语 | 工具执行后返回给Agent的信息。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Action Space | 动作空间 | 动作空间 | 术语 | Agent可执行的动作集合。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Handoff | 交接 | Agent交接 | 术语 | 一个Agent把任务交给另一个Agent。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Memory | 记忆 | 记忆 | 术语 | 保存用户偏好、项目背景、历史操作。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Short-term Memory | 短期记忆 | 短期记忆 | 术语 | 当前任务/会话内的上下文。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Long-term Memory | 长期记忆 | 长期记忆 | 术语 | 跨会话保存的信息。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Agentic Memory | 智能体记忆 | Agentic Memory | 术语 | Agent将关键知识写入外部长期记忆并按需检索。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Persistent Memory | 持久记忆 | 持久化记忆 | 术语 | 可长期保存和恢复的记忆。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Human-in-the-loop | 人在回路 | 人工审批 | 术语 | 关键动作由人确认。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Guardrails | 护栏 | 护栏 | 术语 | 限制AI行为、输出和权限的规则。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Tracing | 追踪 | 执行追踪 | 术语 | 记录Agent调用模型、工具、交接、错误过程。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Observability | 可观测性 | 可观测性 | 术语 | 监控、调试和评估Agent行为。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Audit Log | 审计日志 | 审计日志 | 术语 | 记录谁在何时让Agent做了什么。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Checkpoint | 检查点 | 检查点 | 术语 | 任务中断后可恢复的状态保存。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Rollback | 回滚 | 回滚 | 术语 | 恢复到之前版本。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Long-horizon Task | 长跨度任务 | 长链路任务 | 术语 | 需要很多步骤才能完成的任务。 |  |  |  |  |  |  |  |
| 04_Agent智能体 | Loop Engineering | 循环工程 | Loop Engineering | 术语 | 设计Agent自动执行、检查、修复的循环。 |  |  |  |  |  |  |  |
| 05_MCP_A2A_AGUI_NLWeb协议 | MCP | Model Context Protocol 直译：模型上下文协议 | 模型上下文协议 | 协议/术语 | 连接AI应用与外部工具/数据源的开放协议。 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| 05_MCP_A2A_AGUI_NLWeb协议 | MCP Host | MCP主机 | MCP主机 | 协议/术语 | 承载AI和MCP客户端的应用。 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| 05_MCP_A2A_AGUI_NLWeb协议 | MCP Client | MCP客户端 | MCP客户端 | 协议/术语 | 负责和MCP Server通信的组件。 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| 05_MCP_A2A_AGUI_NLWeb协议 | MCP Server | MCP服务端 | MCP服务端 | 协议/术语 | 对外提供工具、资源、提示模板的服务。 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| 05_MCP_A2A_AGUI_NLWeb协议 | MCP Tool | MCP工具 | MCP工具 | 协议/术语 | AI可以通过MCP调用的具体能力。 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| 05_MCP_A2A_AGUI_NLWeb协议 | MCP Resource | MCP资源 | MCP资源 | 协议/术语 | AI可以通过MCP读取的数据或文件。 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| 05_MCP_A2A_AGUI_NLWeb协议 | MCP Prompt | MCP提示 | MCP提示模板 | 协议/术语 | MCP Server提供的标准提示模板。 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| 05_MCP_A2A_AGUI_NLWeb协议 | FastMCP | 快速MCP | FastMCP | 协议/术语 | 快速构建MCP Server的工具/框架。 |  |  |  |  |  |  | https://github.com/modelcontextprotocol/python-sdk |
| 05_MCP_A2A_AGUI_NLWeb协议 | A2A | Agent to Agent 直译：智能体到智能体 | Agent2Agent协议 | 协议/术语 | Agent之间互相发现、通信、协作的协议方向。 |  |  |  |  |  |  | https://developers.googleblog.com/ |
| 05_MCP_A2A_AGUI_NLWeb协议 | Agent Card | 智能体卡片 | Agent Card | 协议/术语 | 描述Agent能力、端点、认证方式的公开说明。 |  |  |  |  |  |  | https://developers.googleblog.com/ |
| 05_MCP_A2A_AGUI_NLWeb协议 | AG-UI | Agent-User Interaction 直译：智能体-用户交互 | AG-UI协议 | 协议/术语 | 连接Agent后端和前端UI的事件式协议。 |  |  |  |  |  |  | https://docs.ag-ui.com/ |
| 05_MCP_A2A_AGUI_NLWeb协议 | NLWeb | Natural Language Web 直译：自然语言网页 | NLWeb | 协议/术语 | 让网站提供自然语言接口和Agent可访问入口。 |  |  |  |  |  |  | https://github.com/nlweb-ai/NLWeb |
| 05_MCP_A2A_AGUI_NLWeb协议 | AP2 | Agent Payments Protocol 直译：智能体支付协议 | Agent支付协议 | 协议/术语 | 面向Agent代用户付款/下单的支付协议方向。 |  |  |  |  |  |  |  |
| 05_MCP_A2A_AGUI_NLWeb协议 | Tool Registry | 工具注册表 | 工具注册表 | 协议/术语 | Agent可用工具的清单和目录。 |  |  |  |  |  |  |  |
| 05_MCP_A2A_AGUI_NLWeb协议 | Tool Schema | 工具结构 | 工具Schema | 协议/术语 | 定义工具名称、参数、返回值。 |  |  |  |  |  |  |  |
| 05_MCP_A2A_AGUI_NLWeb协议 | Tool Poisoning | 工具投毒 | 工具投毒 | 协议/术语 | 恶意工具说明诱导Agent错误执行。 |  |  |  |  |  |  |  |
| 05_MCP_A2A_AGUI_NLWeb协议 | Connector Protocol | 连接器协议 | 连接器协议 | 协议/术语 | 统一连接外部应用和服务的协议。 |  |  |  |  |  |  |  |
| 05_MCP_A2A_AGUI_NLWeb协议 | Protocol Adapter | 协议适配器 | 协议适配器 | 协议/术语 | 在不同协议之间做转换。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Vibe Coding | 氛围编程/感觉编程 | Vibe Coding | 术语 | 人描述想要的效果，AI生成/修改/调试代码。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Agentic Coding | 智能体编程 | Agentic Coding | 术语 | AI自动读仓库、改代码、跑测试、提交PR。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | AI Pair Programming | AI结对编程 | AI结对编程 | 术语 | AI像搭档一样和人一起写代码。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Prompt-to-Code | 提示到代码 | 提示词生成代码 | 术语 | 用自然语言生成代码片段或模块。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Prompt-to-App | 提示到应用 | 提示词生成应用 | 术语 | 用一句或一段需求生成完整应用。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Spec-driven Development | 规格驱动开发 | 规格驱动开发 | 术语 | 先写清需求和验收标准，再让AI开发。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | PRD | Product Requirements Document 直译：产品需求文档 | 产品需求文档 | 术语 | 产品功能、用户流程、验收标准说明。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | TRD | Technical Requirements Document 直译：技术需求文档 | 技术需求文档 | 术语 | 技术架构、接口、数据结构、限制说明。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Implementation Plan | 实施计划 | 实现计划 | 术语 | AI写代码前的分步方案。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Acceptance Criteria | 验收标准 | 验收标准 | 术语 | 判断任务是否完成的明确条件。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Codebase Understanding | 代码库理解 | 代码库理解 | 术语 | AI阅读项目结构、依赖和业务逻辑。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Repo-aware Agent | 仓库感知智能体 | 仓库感知Agent | 术语 | 理解整个Git仓库，而不是只看当前文件。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Code Context | 代码上下文 | 代码上下文 | 术语 | 让AI理解相关文件、依赖、规则。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Semantic Code Search | 语义代码搜索 | 语义代码搜索 | 术语 | 按意图查找代码，而非只靠关键词。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Code Indexing | 代码索引 | 代码索引 | 术语 | 为项目代码建立索引以便AI检索。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | AST | Abstract Syntax Tree 直译：抽象语法树 | 抽象语法树 | 术语 | 代码结构化表示，适合静态分析和重构。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | LSP | Language Server Protocol 直译：语言服务器协议 | 语言服务器协议 | 术语 | 为编辑器提供跳转、补全、诊断能力。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Plan Mode | 计划模式 | 计划模式 | 术语 | 先调研和规划，不立即改文件。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Act Mode | 行动模式 | 执行模式 | 术语 | 允许AI改文件、跑命令、调用工具。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Diff | 差异 | 代码差异 | 术语 | 文件改动前后对比。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Patch | 补丁 | 补丁 | 术语 | 可应用到项目的一组代码修改。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Commit | 提交 | Git提交 | 术语 | 一次Git代码变更记录。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Pull Request | 拉取请求 | PR | 术语 | 提交代码变更给项目审查。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Code Review | 代码审查 | 代码审查 | 术语 | 检查代码质量、安全、性能和规范。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Unit Test | 单元测试 | 单元测试 | 术语 | 测试最小功能单元。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Integration Test | 集成测试 | 集成测试 | 术语 | 测试多个模块协作。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | E2E Test | 端到端测试 | 端到端测试 | 术语 | 模拟真实用户流程。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Regression Test | 回归测试 | 回归测试 | 术语 | 确认新改动没有破坏旧功能。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Static Analysis | 静态分析 | 静态分析 | 术语 | 不运行代码也能发现问题。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Lint | 棉絮/清理 | 代码规范检查 | 术语 | 检查格式、风格和潜在错误。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Type Check | 类型检查 | 类型检查 | 术语 | 检查类型错误。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | CI/CD | 持续集成/持续部署 | CI/CD | 术语 | 自动测试、构建、部署。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Git Worktree | Git工作树 | Git工作树 | 术语 | 同一仓库开多个工作区，适合多Agent并行。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Parallel Agents | 并行智能体 | 并行Agent | 术语 | 多个Agent同时做不同分支或任务。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Sandboxed Execution | 沙箱执行 | 沙箱执行 | 术语 | 隔离运行AI命令，降低破坏风险。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Dry Run | 干运行/试运行 | 试运行 | 术语 | 模拟执行，不真正修改或提交。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Rollback Plan | 回滚计划 | 回滚方案 | 术语 | AI改坏后恢复。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | SWE-bench | 软件工程基准 | SWE-bench | 术语 | 评测AI解决真实GitHub issue的代码benchmark。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Silent Failure | 静默失败 | 静默失败 | 术语 | 看起来完成但隐藏bug。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Scope Creep | 范围蔓延 | 范围膨胀 | 术语 | AI越改越多，超出原需求。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Over-engineering | 过度工程 | 过度工程化 | 术语 | 简单需求被AI做复杂。 |  |  |  |  |  |  |  |
| 06_VibeCoding_AI编程 | Context Rot | 上下文腐烂 | 上下文腐烂 | 术语 | 上下文过长/过乱导致模型混乱。 |  |  |  |  |  |  |  |
| 07_AI编程工具_IDE_Agent | OpenAI Codex | 代码抄本/法典 | Codex | 平台/Agent | OpenAI编程Agent，可读写代码、跑测试、处理工程任务。 | 国际顶流 |  |  | 否 | 否 | 是 | https://openai.com/codex |
| 07_AI编程工具_IDE_Agent | Claude Code | Claude代码 | Claude Code | 平台/Agent | Anthropic的终端/IDE编程Agent，适合大型代码库和自动化开发。 | 国际顶流 |  |  | 否 | 否 | 是 | https://github.com/anthropics/claude-code |
| 07_AI编程工具_IDE_Agent | Cursor | 光标 | Cursor | 平台/IDE | AI IDE，主打代码库理解、Agent和计划/执行模式。 | 国际顶流 |  |  | 否 | 否 | 是 | https://cursor.com/ |
| 07_AI编程工具_IDE_Agent | Windsurf | 风帆冲浪 | Windsurf | 平台/IDE | AI IDE，Cascade工作流是其核心亮点。 | 国际高热 |  |  | 否 | 否 | 是 | https://windsurf.com/ |
| 07_AI编程工具_IDE_Agent | GitHub Copilot | GitHub副驾驶 | GitHub Copilot | 平台/IDE插件 | GitHub/微软AI编程助手，覆盖补全、聊天、Agent、PR流程。 | 国际顶流 |  |  | 否 | 否 | 是 | https://github.com/features/copilot |
| 07_AI编程工具_IDE_Agent | Devin | 品牌名 | Devin | 平台/Agent | Cognition的软件工程Agent，偏自动完成工程任务。 | 国际高热 |  |  | 否 | 否 | 部分 | https://devin.ai/ |
| 07_AI编程工具_IDE_Agent | Replit Agent | Replit智能体 | Replit Agent | 平台/应用生成 | 在线生成、开发、部署应用的AI Agent。 | 国际高热 |  |  | 否 | 否 | 部分 | https://replit.com/ai |
| 07_AI编程工具_IDE_Agent | Lovable | 可爱/值得爱 | Lovable | 平台/应用生成 | Prompt-to-App工具，用自然语言生成Web应用。 | 国际高热 |  |  | 否 | 否 | 部分 | https://lovable.dev/ |
| 07_AI编程工具_IDE_Agent | Bolt.new | 螺栓 | Bolt.new | 平台/应用生成 | StackBlitz的浏览器应用生成工具。 | 国际高热 |  |  | 否 | 否 | 部分 | https://bolt.new/ |
| 07_AI编程工具_IDE_Agent | OpenAI Codex | 代码抄本/法典 | Codex | 平台/Agent | OpenAI编程Agent，可读写代码、跑测试、处理工程任务。 | 国际顶流 |  |  | 否 | 否 | 是 | https://openai.com/codex |
| 07_AI编程工具_IDE_Agent | Claude Code | Claude代码 | Claude Code | 平台/Agent | Anthropic的终端/IDE编程Agent，适合大型代码库和自动化开发。 | 国际顶流 |  |  | 否 | 否 | 是 | https://github.com/anthropics/claude-code |
| 07_AI编程工具_IDE_Agent | Cursor | 光标 | Cursor | 平台/IDE | AI IDE，主打代码库理解、Agent和计划/执行模式。 | 国际顶流 |  |  | 否 | 否 | 是 | https://cursor.com/ |
| 07_AI编程工具_IDE_Agent | Windsurf | 风帆冲浪 | Windsurf | 平台/IDE | AI IDE，Cascade工作流是其核心亮点。 | 国际高热 |  |  | 否 | 否 | 是 | https://windsurf.com/ |
| 07_AI编程工具_IDE_Agent | GitHub Copilot | GitHub副驾驶 | GitHub Copilot | 平台/IDE插件 | GitHub/微软AI编程助手，覆盖补全、聊天、Agent、PR流程。 | 国际顶流 |  |  | 否 | 否 | 是 | https://github.com/features/copilot |
| 07_AI编程工具_IDE_Agent | Devin | 品牌名 | Devin | 平台/Agent | Cognition的软件工程Agent，偏自动完成工程任务。 | 国际高热 |  |  | 否 | 否 | 部分 | https://devin.ai/ |
| 07_AI编程工具_IDE_Agent | Replit Agent | Replit智能体 | Replit Agent | 平台/应用生成 | 在线生成、开发、部署应用的AI Agent。 | 国际高热 |  |  | 否 | 否 | 部分 | https://replit.com/ai |
| 07_AI编程工具_IDE_Agent | Lovable | 可爱/值得爱 | Lovable | 平台/应用生成 | Prompt-to-App工具，用自然语言生成Web应用。 | 国际高热 |  |  | 否 | 否 | 部分 | https://lovable.dev/ |
| 07_AI编程工具_IDE_Agent | Bolt.new | 螺栓 | Bolt.new | 平台/应用生成 | StackBlitz的浏览器应用生成工具。 | 国际高热 |  |  | 否 | 否 | 部分 | https://bolt.new/ |
| 07_AI编程工具_IDE_Agent | bolt.diy | 螺栓DIY | bolt.diy | 开源项目 | Bolt的开源版本，可连接多家模型和Ollama。 | A 中高热 | 19000 | 2300 | 是 | 是 | 是 | https://github.com/stackblitz-labs/bolt.diy |
| 07_AI编程工具_IDE_Agent | opencode | 开放代码 | opencode | 开源项目 | 开源终端/IDE coding agent，支持多模型和并行会话。 | SSS 超顶流 | 177000 | 21600 | 是 | 是 | 是 | https://github.com/sst/opencode |
| 07_AI编程工具_IDE_Agent | Gemini CLI | Gemini命令行 | Gemini CLI | 开源项目 | Google开源终端Agent，把Gemini接入开发者命令行。 | SSS 超顶流 | 105000 | 14100 | 是 | 是 | 是 | https://github.com/google-gemini/gemini-cli |
| 07_AI编程工具_IDE_Agent | OpenHands | 开放之手 | OpenHands | 开源项目 | 开源软件工程Agent，可理解为自托管Devin方向。 | SS 顶流 | 77900 | 9900 | 是 | 是 | 是 | https://github.com/All-Hands-AI/OpenHands |
| 07_AI编程工具_IDE_Agent | Cline | 品牌名 | Cline | 开源项目 | VS Code开源coding agent，支持MCP、终端、浏览器等。 | SS 顶流 | 63600 | 6700 | 是 | 是 | 是 | https://github.com/cline/cline |
| 07_AI编程工具_IDE_Agent | Aider | 帮手 | Aider | 开源项目 | 终端AI结对编程工具，适合已有仓库改代码。 | S 高热 | 46500 | 4600 | 是 | 是 | 是 | https://github.com/Aider-AI/aider |
| 07_AI编程工具_IDE_Agent | Continue | 继续 | Continue | 开源项目 | 开源AI代码助手，可接本地/云模型，支持VS Code/JetBrains。 | S 高热 | 34200 | 4800 | 是 | 是 | 是 | https://github.com/continuedev/continue |
| 07_AI编程工具_IDE_Agent | Tabby | 虎斑猫/品牌名 | Tabby | 开源项目 | 自托管AI编程助手，类似私有Copilot。 | S 高热 | 33600 | 1800 | 是 | 是 | 是 | https://github.com/TabbyML/tabby |
| 07_AI编程工具_IDE_Agent | Qwen Code | 通义代码 | Qwen Code | 开源项目 | Qwen生态终端coding agent。 | S 高热 | 25400 | 2500 | 是 | 是 | 是 | https://github.com/QwenLM/qwen-code |
| 07_AI编程工具_IDE_Agent | Roo Code | Roo代码 | Roo Code | 开源项目 | VS Code coding agent生态项目，需注意归档/维护状态。 | S 高热 | 24200 | 3300 | 是 | 是 | 部分 | https://github.com/RooCodeInc/Roo-Code |
| 07_AI编程工具_IDE_Agent | CodeBuddy | 代码伙伴 | 腾讯云CodeBuddy | 平台/IDE | 腾讯云相关AI编程助手。 | 国内高热 |  |  | 否 | 否 | 部分 | https://www.codebuddy.ai/ |
| 07_AI编程工具_IDE_Agent | Trae | 品牌名 | Trae | 平台/IDE | 字节系AI IDE/编程工具方向。 | 国内高热 |  |  | 否 | 否 | 是 | https://www.trae.ai/ |
| 07_AI编程工具_IDE_Agent | Sourcegraph Cody | 源码图 Cody | Cody | 平台/IDE插件 | 面向代码库理解的AI工具。 | 国际中高热 |  |  | 部分 | 部分 | 是 | https://sourcegraph.com/cody |
| 07_AI编程工具_IDE_Agent | Amazon Q Developer | 亚马逊Q开发者 | Amazon Q Developer | 平台/云助手 | AWS编程和云开发助手。 | 国际高热 |  |  | 否 | 否 | 部分 | https://aws.amazon.com/q/developer/ |
| 07_AI编程工具_IDE_Agent | Tabnine | 品牌名 | Tabnine | 平台/IDE插件 | AI代码补全工具。 | 国际中高热 |  |  | 否 | 部分 | 是 | https://www.tabnine.com/ |
| 07_AI编程工具_IDE_Agent | v0 | 零版本 | v0 | 平台/UI生成 | Vercel的AI前端/UI生成工具。 | 国际高热 |  |  | 否 | 否 | 部分 | https://v0.dev/ |
| 08_Agent框架_RAG框架_开发库 | LangChain | 语言链 | LangChain | 开源项目 | 构建Agent、RAG、工具调用、模型编排的核心框架。 | SSS 超顶流 | 139784 | 23183 | 是 | 部分 | 是 | https://github.com/langchain-ai/langchain |
| 08_Agent框架_RAG框架_开发库 | LangGraph | 语言图 | LangGraph | 开源项目 | 有状态、长任务、多Agent、可恢复的Agent编排框架。 | S 高热 | 35322 | 5924 | 是 | 部分 | 是 | https://github.com/langchain-ai/langgraph |
| 08_Agent框架_RAG框架_开发库 | Dify | 品牌名 | Dify | 开源项目/平台 | 生产级Agentic workflow、RAG、AI应用平台。 | SSS 超顶流 | 145982 | 22959 | 是 | 是 | 是 | https://github.com/langgenius/dify |
| 08_Agent框架_RAG框架_开发库 | LlamaIndex | Llama索引 | LlamaIndex | 开源项目 | 文档、数据库、RAG、知识库接入LLM的框架。 | SS 顶流 | 50200 | 7600 | 是 | 部分 | 是 | https://github.com/run-llama/llama_index |
| 08_Agent框架_RAG框架_开发库 | CrewAI | 团队AI | CrewAI | 开源项目 | 多角色Agent协作与自动化框架。 | SS 顶流 | 54100 | 7600 | 是 | 部分 | 是 | https://github.com/crewAIInc/crewAI |
| 08_Agent框架_RAG框架_开发库 | Flowise | 流式智能 | Flowise | 开源项目 | 拖拽式构建LLM应用、Agent和RAG流程。 | SS 顶流 | 53800 | 24600 | 是 | 是 | 是 | https://github.com/FlowiseAI/Flowise |
| 08_Agent框架_RAG框架_开发库 | Langflow | 语言流 | Langflow | 开源项目/平台 | 可视化构建AI Agent、RAG应用和MCP Server。 | SSS 超顶流 | 150000 | 9300 | 是 | 是 | 是 | https://github.com/langflow-ai/langflow |
| 08_Agent框架_RAG框架_开发库 | AutoGen | 自动生成 | AutoGen | 开源项目 | 微软多Agent对话与协作框架，当前需注意维护模式。 | SS 顶流 | 59100 | 8900 | 是 | 部分 | 部分 | https://github.com/microsoft/autogen |
| 08_Agent框架_RAG框架_开发库 | Semantic Kernel | 语义内核 | Semantic Kernel | 开源项目 | 微软AI编排SDK，适合企业.NET/Python/Java生态。 | S 高热 | 28200 | 4700 | 是 | 部分 | 是 | https://github.com/microsoft/semantic-kernel |
| 08_Agent框架_RAG框架_开发库 | OpenAI Agents SDK | OpenAI智能体SDK | OpenAI Agents SDK | 开源项目/SDK | OpenAI官方Agent开发SDK，支持工具、交接、护栏、追踪。 | A 中高热 | 11000 | 1800 | 是 | 部分 | 是 | https://github.com/openai/openai-agents-python |
| 08_Agent框架_RAG框架_开发库 | Google ADK | Google智能体开发套件 | Google ADK | SDK/框架 | Google Agent Development Kit，用于开发Agent应用。 | B 垂直热 | 8000 | 900 | 是 | 部分 | 部分 | https://github.com/google/adk-python |
| 08_Agent框架_RAG框架_开发库 | Pydantic AI | Pydantic AI | Pydantic AI | 开源项目 | 类型安全Python Agent框架，适合结构化输出。 | A 中高热 | 11000 | 900 | 是 | 部分 | 是 | https://github.com/pydantic/pydantic-ai |
| 08_Agent框架_RAG框架_开发库 | Haystack | 干草堆 | Haystack | 开源项目 | RAG、搜索、问答和LLM应用框架。 | S 高热 | 23000 | 4200 | 是 | 部分 | 是 | https://github.com/deepset-ai/haystack |
| 08_Agent框架_RAG框架_开发库 | DSPy | DSPy | DSPy | 开源项目 | 可优化LLM pipeline的编程框架。 | S 高热 | 28000 | 2200 | 是 | 部分 | 部分 | https://github.com/stanfordnlp/dspy |
| 08_Agent框架_RAG框架_开发库 | Vercel AI SDK | Vercel AI软件开发套件 | Vercel AI SDK | 开源项目/SDK | 前端/全栈AI应用开发SDK，适合Next.js和流式聊天。 | A 中高热 | 17000 | 2700 | 是 | 部分 | 是 | https://github.com/vercel/ai |
| 08_Agent框架_RAG框架_开发库 | LiteLLM | 轻量LLM | LiteLLM | 开源项目 | 多模型统一调用网关，兼容OpenAI接口。 | S 高热 | 30000 | 4000 | 是 | 是 | 是 | https://github.com/BerriAI/litellm |
| 08_Agent框架_RAG框架_开发库 | OpenRouter | 开放路由器 | OpenRouter | 平台 | 多模型路由平台，统一接入多家模型。 |  |  |  | 否 | 否 | 是 | https://openrouter.ai/ |
| 08_Agent框架_RAG框架_开发库 | Portkey | 端口钥匙 | Portkey | 平台/SDK | LLM网关、路由、观测、成本控制平台。 |  |  |  | 部分 | 部分 | 是 | https://portkey.ai/ |
| 08_Agent框架_RAG框架_开发库 | Mastra | 品牌名 | Mastra | 开源项目 | TypeScript Agent框架。 | A 中高热 | 12000 | 900 | 是 | 部分 | 是 | https://github.com/mastra-ai/mastra |
| 09_本地模型_部署_推理 | Ollama | 品牌名 | Ollama | 开源项目/本地模型 | 本地运行和管理开源大模型的工具。 | SSS 超顶流 | 175000 | 16700 | 是 | 是 | 是 | https://github.com/ollama/ollama |
| 09_本地模型_部署_推理 | Open WebUI | 开放网页界面 | Open WebUI | 开源项目/本地平台 | 本地/自托管AI聊天、知识库、多模型入口。 | SSS 超顶流 | 142000 | 20500 | 是 | 是 | 是 | https://github.com/open-webui/open-webui |
| 09_本地模型_部署_推理 | Hugging Face Transformers | 拥抱脸变换器 | Transformers | 开源项目/模型库 | 全球最核心的开源模型库之一。 | SSS 超顶流 | 162000 | 33600 | 是 | 是 | 部分 | https://github.com/huggingface/transformers |
| 09_本地模型_部署_推理 | llama.cpp | Llama C++ | llama.cpp | 开源项目/推理引擎 | GGUF、本地量化模型、CPU/GPU推理核心项目。 | SSS 超顶流 | 117000 | 19800 | 是 | 是 | 部分 | https://github.com/ggml-org/llama.cpp |
| 09_本地模型_部署_推理 | vLLM | 品牌名 | vLLM | 开源项目/推理服务 | 高吞吐LLM serving框架，适合服务器部署。 | SS 顶流 | 83400 | 18300 | 是 | 是 | 部分 | https://github.com/vllm-project/vllm |
| 09_本地模型_部署_推理 | Text Generation WebUI | 文本生成网页界面 | text-generation-webui | 开源项目/本地平台 | 本地LLM WebUI，早期本地模型玩家常用。 | S 高热 | 46000 | 5700 | 是 | 是 | 部分 | https://github.com/oobabooga/text-generation-webui |
| 09_本地模型_部署_推理 | LocalAI | 本地AI | LocalAI | 开源项目/本地API | OpenAI兼容本地API服务。 | S 高热 | 34000 | 2500 | 是 | 是 | 是 | https://github.com/mudler/LocalAI |
| 09_本地模型_部署_推理 | LM Studio | 语言模型工作室 | LM Studio | 平台/本地软件 | 本地模型GUI工具，适合新手运行和聊天。 |  |  |  | 否 | 是 | 部分 | https://lmstudio.ai/ |
| 09_本地模型_部署_推理 | AnythingLLM | 任何东西LLM | AnythingLLM | 开源项目/知识库 | 本地/企业知识库和AI应用平台。 | SS 顶流 | 50000 | 5200 | 是 | 是 | 是 | https://github.com/Mintplex-Labs/anything-llm |
| 09_本地模型_部署_推理 | RAGFlow | RAG流 | RAGFlow | 开源项目/RAG平台 | 文档解析与RAG平台。 | SS 顶流 | 70000 | 6500 | 是 | 是 | 是 | https://github.com/infiniflow/ragflow |
| 09_本地模型_部署_推理 | PrivateGPT | 私有GPT | PrivateGPT | 开源项目/RAG | 私有化文档问答/RAG工具。 | SS 顶流 | 55000 | 7300 | 是 | 是 | 部分 | https://github.com/zylon-ai/private-gpt |
| 09_本地模型_部署_推理 | TGI | 文本生成推理 | Text Generation Inference | 开源项目/推理服务 | Hugging Face文本生成推理服务。 | A 中高热 | 10000 | 1200 | 是 | 是 | 部分 | https://github.com/huggingface/text-generation-inference |
| 09_本地模型_部署_推理 | TensorRT-LLM | TensorRT大语言模型 | TensorRT-LLM | 开源项目/推理优化 | NVIDIA高性能LLM推理优化框架。 | A 中高热 | 10000 | 1400 | 是 | 是 | 部分 | https://github.com/NVIDIA/TensorRT-LLM |
| 09_本地模型_部署_推理 | MLX | 机器学习X | MLX | 开源项目/本地推理 | Apple Silicon本地模型框架。 | A 中高热 | 19000 | 1100 | 是 | 是 | 部分 | https://github.com/ml-explore/mlx |
| 09_本地模型_部署_推理 | ONNX Runtime | 开放神经网络交换运行时 | ONNX Runtime | 开源项目/推理运行时 | 跨平台模型推理运行时。 | A 中高热 | 17000 | 4000 | 是 | 是 | 部分 | https://github.com/microsoft/onnxruntime |
| 10_RAG_知识库_向量数据库 | FAISS | Facebook AI相似度搜索 | FAISS | 开源项目/向量检索 | Meta开源高性能向量检索库。 | S 高热 | 36000 | 4700 | 是 | 是 | 是 | https://github.com/facebookresearch/faiss |
| 10_RAG_知识库_向量数据库 | Milvus | 品牌名 | Milvus | 开源项目/向量数据库 | 云原生向量数据库，适合大规模RAG。 | S 高热 | 44900 | 4100 | 是 | 是 | 是 | https://github.com/milvus-io/milvus |
| 10_RAG_知识库_向量数据库 | Qdrant | 品牌名 | Qdrant | 开源项目/向量数据库 | Rust实现的向量数据库/搜索引擎。 | S 高热 | 32500 | 2400 | 是 | 是 | 是 | https://github.com/qdrant/qdrant |
| 10_RAG_知识库_向量数据库 | Chroma | 色度 | Chroma | 开源项目/向量库 | 轻量AI搜索基础设施，本地RAG常用。 | S 高热 | 28500 | 2300 | 是 | 是 | 是 | https://github.com/chroma-core/chroma |
| 10_RAG_知识库_向量数据库 | Weaviate | 品牌名 | Weaviate | 开源项目/向量数据库 | 向量数据库，支持语义搜索和结构化过滤。 | A 中高热 | 16400 | 1300 | 是 | 是 | 是 | https://github.com/weaviate/weaviate |
| 10_RAG_知识库_向量数据库 | pgvector | Postgres向量 | pgvector | 开源项目/数据库扩展 | PostgreSQL向量扩展。 | A 中高热 | 15000 | 700 | 是 | 是 | 是 | https://github.com/pgvector/pgvector |
| 10_RAG_知识库_向量数据库 | Pinecone | 松果 | Pinecone | 平台/向量数据库 | 托管向量数据库平台。 |  |  |  | 否 | 否 | 是 | https://www.pinecone.io/ |
| 10_RAG_知识库_向量数据库 | LanceDB | Lance数据库 | LanceDB | 开源项目/向量数据库 | 向量数据库/多模态数据湖方向。 | B 垂直热 | 8000 | 700 | 是 | 是 | 是 | https://github.com/lancedb/lancedb |
| 10_RAG_知识库_向量数据库 | Elasticsearch | 弹性搜索 | Elasticsearch | 开源项目/搜索引擎 | 搜索引擎，支持关键词/混合搜索。 | SS 顶流 | 72000 | 25000 | 是 | 是 | 是 | https://github.com/elastic/elasticsearch |
| 10_RAG_知识库_向量数据库 | OpenSearch | 开放搜索 | OpenSearch | 开源项目/搜索引擎 | 开源搜索和分析引擎。 | A 中高热 | 11000 | 5000 | 是 | 是 | 是 | https://github.com/opensearch-project/OpenSearch |
| 10_RAG_知识库_向量数据库 | Meilisearch | Meili搜索 | Meilisearch | 开源项目/搜索引擎 | 轻量全文搜索引擎。 | SS 顶流 | 50000 | 2000 | 是 | 是 | 是 | https://github.com/meilisearch/meilisearch |
| 10_RAG_知识库_向量数据库 | Typesense | 类型感知 | Typesense | 开源项目/搜索引擎 | 快速容错搜索引擎。 | S 高热 | 23000 | 1600 | 是 | 是 | 是 | https://github.com/typesense/typesense |
| 11_BrowserAgent_AI浏览器 | Browser-use | 浏览器使用 | Browser-use | 开源项目/浏览器Agent | 让AI Agent操作真实网站和浏览器任务。 | SS 顶流 | 99800 | 11100 | 是 | 部分 | 是 | https://github.com/browser-use/browser-use |
| 11_BrowserAgent_AI浏览器 | Stagehand | 舞台助手 | Stagehand | 开源项目/浏览器自动化 | Browserbase出品，用自然语言+代码控制浏览器。 | S 高热 | 23200 | 1600 | 是 | 部分 | 是 | https://github.com/browserbase/stagehand |
| 11_BrowserAgent_AI浏览器 | Playwright | 剧作家 | Playwright | 开源项目/浏览器自动化 | 微软浏览器自动化和E2E测试库。 | SS 顶流 | 75000 | 4300 | 是 | 是 | 是 | https://github.com/microsoft/playwright |
| 11_BrowserAgent_AI浏览器 | Selenium | 硒 | Selenium | 开源项目/浏览器自动化 | 老牌浏览器自动化框架。 | S 高热 | 33000 | 8000 | 是 | 是 | 是 | https://github.com/SeleniumHQ/selenium |
| 11_BrowserAgent_AI浏览器 | Puppeteer | 操偶师 | Puppeteer | 开源项目/浏览器自动化 | Node.js控制Chrome/Chromium的自动化库。 | SS 顶流 | 92000 | 9000 | 是 | 是 | 是 | https://github.com/puppeteer/puppeteer |
| 11_BrowserAgent_AI浏览器 | Browserbase | 浏览器基地 | Browserbase | 平台/浏览器基础设施 | 为浏览器Agent提供云端浏览器基础设施。 |  |  |  | 否 | 否 | 是 | https://www.browserbase.com/ |
| 11_BrowserAgent_AI浏览器 | Comet | 彗星 | Perplexity Comet | 平台/AI浏览器 | Perplexity AI浏览器。 |  |  |  | 否 | 否 | 否 | https://www.perplexity.ai/comet |
| 11_BrowserAgent_AI浏览器 | Dia | 品牌名 | Dia Browser | 平台/AI浏览器 | The Browser Company的AI浏览器方向产品。 |  |  |  | 否 | 否 | 否 | https://www.diabrowser.com/ |
| 11_BrowserAgent_AI浏览器 | Operator | 操作者 | OpenAI Operator | 平台/网页Agent | OpenAI网页任务执行Agent方向产品。 |  |  |  | 否 | 否 | 否 | https://openai.com/index/introducing-operator/ |
| 11_BrowserAgent_AI浏览器 | Computer Use | 电脑使用 | Computer Use | 术语/能力 | AI看屏幕、点按钮、输入文字的能力。 |  |  |  |  |  | 是 |  |
| 12_设计_图像_视频AI | Lovart AI | Love+Art：爱艺术 | Lovart AI | 平台/AI设计Agent | AI Design Agent，从品牌描述生成logo、包装、社媒、视频广告等资产。 | 新兴高热 |  |  | 否 | 否 | 部分 | https://www.lovart.ai/ |
| 12_设计_图像_视频AI | LiblibAI | 哩布哩布 | 哩布哩布AI | 平台/AI创作社区 | 国内AI创作平台/模型社区，支持在线WebUI、ComfyUI、生图、模型训练、LoRA。 | 国内高热 |  |  | 否 | 否 | 部分 | https://www.liblib.art/ |
| 12_设计_图像_视频AI | Civitai | 品牌名 | Civitai | 平台/模型社区 | 全球AI图像模型/LoRA/作品社区。 | 国际高热 |  |  | 部分 | 否 | 部分 | https://civitai.com/ |
| 12_设计_图像_视频AI | Hugging Face Hub | 拥抱脸中心 | Hugging Face模型社区 | 平台/模型社区 | 模型、数据集、Spaces、开源AI社区中心。 | 国际顶流 |  |  | 部分 | 否 | 部分 | https://huggingface.co/ |
| 12_设计_图像_视频AI | ComfyUI | 舒适UI | ComfyUI | 开源项目/图像视频工作流 | 节点式AI图像/视频/3D/音频生成工作流工具。 | SSS 超顶流 | 118000 | 13800 | 是 | 是 | 是 | https://github.com/Comfy-Org/ComfyUI |
| 12_设计_图像_视频AI | ComfyUI Manager | ComfyUI管理器 | ComfyUI Manager | 开源项目/ComfyUI插件 | 管理ComfyUI自定义节点、插件、模型和工作流。 | A 中高热 | 15000 | 1500 | 是 | 是 | 是 | https://github.com/Comfy-Org/ComfyUI-Manager |
| 12_设计_图像_视频AI | AUTOMATIC1111 | 自动1111 | Stable Diffusion WebUI | 开源项目/图像生成 | 老牌Stable Diffusion本地绘图WebUI。 | SSS 超顶流 | 150000 | 28000 | 是 | 是 | 部分 | https://github.com/AUTOMATIC1111/stable-diffusion-webui |
| 12_设计_图像_视频AI | InvokeAI | 调用AI | InvokeAI | 开源项目/图像生成 | AI绘图和创意工作流工具。 | S 高热 | 27000 | 3000 | 是 | 是 | 部分 | https://github.com/invoke-ai/InvokeAI |
| 12_设计_图像_视频AI | Hugging Face Diffusers | 扩散器 | Diffusers | 开源项目/生成模型库 | 图像/视频/音频生成模型库。 | S 高热 | 33900 | 7100 | 是 | 是 | 部分 | https://github.com/huggingface/diffusers |
| 12_设计_图像_视频AI | ControlNet | 控制网络 | ControlNet | 技术/模型 | 用线稿、姿势、深度、边缘等控制图像生成。 | S 高热 | 25000 | 3000 | 是 | 是 | 部分 | https://github.com/lllyasviel/ControlNet |
| 12_设计_图像_视频AI | Fooocus | 焦点 | Fooocus | 开源项目/图像生成 | 简化版AI绘图界面，降低SD使用门槛。 | S 高热 | 45000 | 5000 | 是 | 是 | 部分 | https://github.com/lllyasviel/Fooocus |
| 12_设计_图像_视频AI | Midjourney | 中途旅程 | Midjourney | 平台/图像生成 | 高质量商业AI绘图平台。 | 国际顶流 |  |  | 否 | 否 | 否 | https://www.midjourney.com/ |
| 12_设计_图像_视频AI | Stable Diffusion | 稳定扩散 | Stable Diffusion | 模型/生态 | 开源图像生成模型生态基础。 | 国际顶流 |  |  | 部分 | 是 | 部分 | https://stability.ai/ |
| 12_设计_图像_视频AI | Flux | 通量/流动 | Flux | 模型/生态 | 新一代高质量图像模型生态。 | 国际高热 |  |  | 部分 | 部分 | 部分 | https://blackforestlabs.ai/ |
| 12_设计_图像_视频AI | Runway | 跑道 | Runway | 平台/视频生成 | AI视频生成和编辑平台。 | 国际高热 |  |  | 否 | 否 | 否 | https://runwayml.com/ |
| 12_设计_图像_视频AI | Pika | 品牌名 | Pika | 平台/视频生成 | 文生视频/图生视频平台。 | 国际高热 |  |  | 否 | 否 | 否 | https://pika.art/ |
| 12_设计_图像_视频AI | Luma Dream Machine | 梦境机器 | Luma Dream Machine | 平台/视频生成 | AI视频生成平台。 | 国际高热 |  |  | 否 | 否 | 否 | https://lumalabs.ai/dream-machine |
| 12_设计_图像_视频AI | Kling | 可灵 | 可灵AI | 平台/视频生成 | 国内知名AI视频生成模型/平台。 | 国内高热 |  |  | 否 | 否 | 否 | https://klingai.kuaishou.com/ |
| 12_设计_图像_视频AI | Veo | 品牌名 | Google Veo | 模型/视频生成 | Google视频生成模型。 | 国际顶流 |  |  | 否 | 否 | 否 | https://deepmind.google/technologies/veo/ |
| 12_设计_图像_视频AI | Sora | 天空/品牌名 | OpenAI Sora | 模型/视频生成 | OpenAI视频生成模型/产品。 | 国际顶流 |  |  | 否 | 否 | 否 | https://openai.com/sora/ |
| 12_设计_图像_视频AI | Canva AI | Canva AI | Canva AI | 平台/设计 | 在线设计平台的AI能力，适合海报/PPT/社媒。 | 国际顶流 |  |  | 否 | 否 | 否 | https://www.canva.com/ |
| 12_设计_图像_视频AI | Figma AI | Figma AI | Figma AI | 平台/UI设计 | UI/产品设计工具中的AI能力。 | 国际顶流 |  |  | 否 | 否 | 部分 | https://www.figma.com/ai/ |
| 12_设计_图像_视频AI | Framer AI | Framer AI | Framer AI | 平台/网站生成 | AI生成和编辑网站页面。 | 国际高热 |  |  | 否 | 否 | 部分 | https://www.framer.com/ |
| 13_Obsidian_第二大脑_个人知识库 | Obsidian | 黑曜石 | Obsidian | 软件/知识管理 | 本地Markdown知识库，适合做AI长期记忆和RAG数据源。 | 高热 |  |  | 否 | 是 | 是 | https://obsidian.md/ |
| 13_Obsidian_第二大脑_个人知识库 | NotebookLM | 笔记本语言模型 | NotebookLM | 平台/资料AI | Google资料型AI笔记工具，基于上传资料问答和总结。 | 国际高热 |  |  | 否 | 否 | 否 | https://notebooklm.google/ |
| 13_Obsidian_第二大脑_个人知识库 | Notion AI | 概念AI | Notion AI | 平台/知识库 | 在线文档/数据库/知识库中的AI能力。 | 国际顶流 |  |  | 否 | 否 | 部分 | https://www.notion.com/product/ai |
| 13_Obsidian_第二大脑_个人知识库 | Logseq | 日志序列 | Logseq | 开源项目/知识管理 | 本地优先双链笔记。 | S 高热 | 34000 | 1900 | 是 | 是 | 是 | https://github.com/logseq/logseq |
| 13_Obsidian_第二大脑_个人知识库 | Roam Research | 漫游研究 | Roam Research | 平台/知识管理 | 双链笔记工具代表。 | 国际中高热 |  |  | 否 | 否 | 否 | https://roamresearch.com/ |
| 13_Obsidian_第二大脑_个人知识库 | Tana | 品牌名 | Tana | 平台/知识管理 | 结构化笔记/知识管理/AI工作流工具。 | 国际中高热 |  |  | 否 | 否 | 部分 | https://tana.inc/ |
| 13_Obsidian_第二大脑_个人知识库 | Heptabase | 七基底 | Heptabase | 平台/知识管理 | 卡片式白板知识管理。 | 国际中高热 |  |  | 否 | 否 | 部分 | https://heptabase.com/ |
| 13_Obsidian_第二大脑_个人知识库 | Readwise | 阅读智慧 | Readwise | 平台/阅读管理 | 阅读标注同步工具。 | 国际高热 |  |  | 否 | 否 | 部分 | https://readwise.io/ |
| 13_Obsidian_第二大脑_个人知识库 | Zotero | 品牌名 | Zotero | 开源项目/文献管理 | 文献管理工具，可作为论文资料库。 | A 中高热 | 11000 | 800 | 是 | 是 | 部分 | https://github.com/zotero/zotero |
| 13_Obsidian_第二大脑_个人知识库 | Pieces | 碎片 | Pieces | 软件/开发者记忆 | 开发者本地优先AI工作流记忆工具。 | 国际中高热 |  |  | 否 | 是 | 是 | https://pieces.app/ |
| 13_Obsidian_第二大脑_个人知识库 | Anytype | 任意类型 | Anytype | 开源项目/知识管理 | 本地优先对象化知识库。 | B 垂直热 | 6000 | 500 | 是 | 是 | 部分 | https://github.com/anyproto/anytype-ts |
| 13_Obsidian_第二大脑_个人知识库 | Raindrop.io | 雨滴 | Raindrop.io | 平台/书签管理 | 书签管理工具，可做AI资料入口。 | 国际中高热 |  |  | 否 | 否 | 部分 | https://raindrop.io/ |
| 13_Obsidian_第二大脑_个人知识库 | Omnivore | 杂食者 | Omnivore | 开源项目/阅读管理 | 开源稍后读/阅读器。 | A 中高热 | 14000 | 900 | 是 | 部分 | 部分 | https://github.com/omnivore-app/omnivore |
| 14_自动化_Workflow_低代码 | n8n | 品牌名 | n8n | 开源项目/自动化 | 可自托管自动化工作流平台，支持AI Agent节点和大量连接器。 | SS 顶流 | 90000 | 25000 | 是 | 是 | 是 | https://github.com/n8n-io/n8n |
| 14_自动化_Workflow_低代码 | Dify Workflow | Dify工作流 | Dify工作流 | 功能/工作流 | 在Dify中编排LLM、RAG、工具和业务流程。 | SSS 超顶流 | 145982 | 22959 | 是 | 是 | 是 | https://dify.ai/ |
| 14_自动化_Workflow_低代码 | Flowise | 流式智能 | Flowise | 开源项目/工作流 | 拖拽式AI workflow和Agent构建。 | SS 顶流 | 53800 | 24600 | 是 | 是 | 是 | https://github.com/FlowiseAI/Flowise |
| 14_自动化_Workflow_低代码 | Langflow | 语言流 | Langflow | 开源项目/低代码 | 低代码构建Agent、RAG和MCP Server。 | SSS 超顶流 | 150000 | 9300 | 是 | 是 | 是 | https://github.com/langflow-ai/langflow |
| 14_自动化_Workflow_低代码 | Zapier | 品牌名 | Zapier | 平台/自动化 | 自动化连接器平台。 |  |  |  | 否 | 否 | 部分 | https://zapier.com/ |
| 14_自动化_Workflow_低代码 | Make | 制作 | Make | 平台/自动化 | 可视化自动化平台。 |  |  |  | 否 | 否 | 部分 | https://www.make.com/ |
| 14_自动化_Workflow_低代码 | Pipedream | 管道梦 | Pipedream | 平台/自动化 | 开发者自动化和API工作流平台。 |  |  |  | 部分 | 否 | 部分 | https://pipedream.com/ |
| 14_自动化_Workflow_低代码 | Activepieces | 活动组件 | Activepieces | 开源项目/自动化 | 开源自动化平台。 | A 中高热 | 18000 | 2200 | 是 | 是 | 是 | https://github.com/activepieces/activepieces |
| 14_自动化_Workflow_低代码 | Node-RED | 节点红 | Node-RED | 开源项目/自动化 | 可视化流程编排工具。 | S 高热 | 20000 | 3400 | 是 | 是 | 部分 | https://github.com/node-red/node-red |
| 14_自动化_Workflow_低代码 | Temporal | 时间性的 | Temporal | 开源项目/工作流引擎 | 持久工作流引擎，适合可靠长流程。 | A 中高热 | 15000 | 2000 | 是 | 是 | 部分 | https://github.com/temporalio/temporal |
| 14_自动化_Workflow_低代码 | Airflow | 气流 | Apache Airflow | 开源项目/数据工作流 | 数据任务调度和工作流编排。 | S 高热 | 40000 | 14000 | 是 | 是 | 部分 | https://github.com/apache/airflow |
| 14_自动化_Workflow_低代码 | Prefect | 长官/完美者 | Prefect | 开源项目/数据工作流 | 数据工作流编排平台。 | A 中高热 | 17000 | 1700 | 是 | 是 | 部分 | https://github.com/PrefectHQ/prefect |
| 15_插件_Skill_Connector | Plugin | 插入件 | 插件 | 术语 | 扩展AI、IDE或平台能力的软件包。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Extension | 扩展 | 扩展 | 术语 | 给工具增加额外功能。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Skill | 技能 | Skill/技能 | 术语 | 把任务流程、说明、脚本和资源打包给Agent使用。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Agent Skill | 智能体技能 | Agent技能 | 术语 | 面向Agent的可复用能力包。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | SKILL.md | 技能说明文件 | SKILL.md | 术语 | 描述技能用途、流程和约束的Markdown文件。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Skill Pack | 技能包 | 技能包 | 术语 | 一组相关技能的集合。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Connector | 连接器 | 连接器 | 术语 | 连接Gmail、GitHub、Drive、Slack、Notion等服务。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Google Drive Connector | Google Drive连接器 | Google Drive连接器 | 术语 | 让AI访问和处理Google Drive文件。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Gmail Connector | Gmail连接器 | Gmail连接器 | 术语 | 让AI检索、总结、处理邮件。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | GitHub Connector | GitHub连接器 | GitHub连接器 | 术语 | 让AI读取issue、PR、仓库和CI。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Slack Connector | Slack连接器 | Slack连接器 | 术语 | 让AI读取和总结Slack频道内容。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Jira Connector | Jira连接器 | Jira连接器 | 术语 | 让AI处理Jira任务和项目记录。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Linear Connector | Linear连接器 | Linear连接器 | 术语 | 让AI处理Linear issue和项目。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Tool Manifest | 工具清单 | 工具清单 | 术语 | 描述工具能力、参数和权限。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Agent Manifest | 智能体清单 | Agent清单 | 术语 | 描述Agent能力、规则和入口。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | AGENTS.md | 智能体说明文件 | AGENTS.md | 术语 | 给coding agent读取的项目规则文件。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | CLAUDE.md | Claude说明文件 | CLAUDE.md | 术语 | Claude Code常用项目规则和上下文文件。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | .cursorrules | Cursor规则 | Cursor规则文件 | 术语 | 给Cursor定义项目规范和偏好。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | GEMINI.md | Gemini说明文件 | GEMINI.md | 术语 | Gemini CLI/Agent读取的项目规则文件。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Slash Command | 斜杠命令 | 斜杠命令 | 术语 | /review、/test等快捷指令。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Hook | 钩子 | 钩子 | 术语 | 在某事件前后自动执行脚本或检查。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Pre-tool Hook | 工具前钩子 | 工具调用前钩子 | 术语 | 工具执行前审批或检查。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Post-tool Hook | 工具后钩子 | 工具调用后钩子 | 术语 | 工具执行后记录或校验。 |  |  |  |  |  |  |  |
| 15_插件_Skill_Connector | Monitor | 监视器 | 监控组件 | 术语 | 观察Agent行为和日志。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Prompt Injection | 提示注入 | 提示注入 | 术语 | 恶意内容诱导AI忽略规则或执行错误操作。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Indirect Prompt Injection | 间接提示注入 | 间接提示注入 | 术语 | 攻击内容藏在网页、邮件、PDF、评论中。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Jailbreak | 越狱 | 越狱 | 术语 | 绕过模型安全规则。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Data Exfiltration | 数据外流 | 数据外泄 | 术语 | 数据被AI或工具泄露到外部。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Secret Leakage | 秘密泄漏 | 密钥泄露 | 术语 | API Key、Token、Cookie泄露。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | System Prompt Leakage | 系统提示泄露 | 系统提示词泄露 | 术语 | 系统/开发者提示被用户或网页诱导泄露。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Tool Poisoning | 工具投毒 | 工具投毒 | 术语 | 恶意工具说明诱导Agent做坏事。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Supply Chain Attack | 供应链攻击 | 供应链攻击 | 术语 | 通过依赖包、插件、模型、MCP Server攻击系统。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | RCE | Remote Code Execution 直译：远程代码执行 | 远程代码执行 | 术语 | 攻击者让系统执行恶意命令。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Sandbox Escape | 沙箱逃逸 | 沙箱逃逸 | 术语 | 突破隔离执行环境。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Privilege Escalation | 权限升级 | 权限提升 | 术语 | 获得更高系统权限。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Excessive Agency | 过度代理权 | 过度自主权 | 术语 | Agent权限过大导致风险。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Least Privilege | 最小权限 | 最小权限原则 | 术语 | 只给AI完成任务必须的权限。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Read-only Mode | 只读模式 | 只读模式 | 术语 | 只允许读取，不允许修改。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Approval Gate | 审批门 | 审批门 | 术语 | 危险操作前必须人工确认。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Allowlist | 允许名单 | 白名单 | 术语 | 只允许访问指定资源。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Denylist | 拒绝名单 | 黑名单 | 术语 | 禁止访问指定资源。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Budget Guardrail | 预算护栏 | 预算护栏 | 术语 | 防止AI消耗过多token或费用。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Audit Trail | 审计轨迹 | 审计链路 | 术语 | 完整记录操作过程。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Red Teaming | 红队测试 | 红队测试 | 术语 | 主动攻击系统发现漏洞。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Canary Token | 金丝雀令牌 | 泄露检测令牌 | 术语 | 用于检测密钥/数据泄露。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Secrets Manager | 密钥管理器 | 密钥管理 | 术语 | 安全保存和调用API Key。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | RBAC | Role-Based Access Control 直译：基于角色访问控制 | 基于角色权限控制 | 术语 | 按角色分配权限。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | Zero Trust | 零信任 | 零信任 | 术语 | 默认不信任任何请求，持续验证。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | OWASP LLM Top 10 | OWASP大语言模型十大风险 | OWASP LLM Top 10 | 术语 | LLM应用安全风险清单。 |  |  |  |  |  |  |  |
| 16_AI安全_权限_合规 | OWASP Agentic Top 10 | OWASP智能体十大风险 | OWASP Agentic Top 10 | 术语 | Agent应用安全风险清单。 |  |  |  |  |  |  |  |
| 17_办公文档AI | Microsoft Copilot | 微软副驾驶 | Microsoft Copilot | 平台/办公AI | Microsoft 365和Windows生态AI助手。 | 国际顶流 |  |  | 否 | 否 | 部分 | https://copilot.microsoft.com/ |
| 17_办公文档AI | Google Gemini for Workspace | Workspace双子座 | Gemini for Workspace | 平台/办公AI | Google Workspace中的AI助手。 | 国际顶流 |  |  | 否 | 否 | 部分 | https://workspace.google.com/solutions/ai/ |
| 17_办公文档AI | Gamma | 伽马 | Gamma | 平台/PPT AI | AI生成PPT、网页和演示内容。 | 国际高热 |  |  | 否 | 否 | 否 | https://gamma.app/ |
| 17_办公文档AI | Tome | 大部头/卷册 | Tome | 平台/PPT AI | AI演示文稿工具。 | 国际中高热 |  |  | 否 | 否 | 否 | https://tome.app/ |
| 17_办公文档AI | Beautiful.ai | 美丽AI | Beautiful.ai | 平台/PPT AI | AI辅助PPT设计平台。 | 国际中高热 |  |  | 否 | 否 | 否 | https://www.beautiful.ai/ |
| 17_办公文档AI | Canva AI Docs | Canva文档AI | Canva Docs/AI | 平台/办公设计AI | Canva中的文档、设计和演示生成能力。 | 国际顶流 |  |  | 否 | 否 | 否 | https://www.canva.com/ |
| 17_办公文档AI | Grammarly | 语法地 | Grammarly | 平台/写作AI | 英文写作和语法AI助手。 | 国际顶流 |  |  | 否 | 否 | 否 | https://www.grammarly.com/ |
| 17_办公文档AI | Wordtune | 调词 | Wordtune | 平台/写作AI | 英文改写和写作工具。 | 国际中高热 |  |  | 否 | 否 | 否 | https://www.wordtune.com/ |
| 17_办公文档AI | QuillBot | 羽毛笔机器人 | QuillBot | 平台/写作AI | 改写、语法、摘要工具。 | 国际高热 |  |  | 否 | 否 | 否 | https://quillbot.com/ |
| 17_办公文档AI | WordBuddy | 单词伙伴 | WordBuddy | 平台/学习AI | AI词汇/英语学习工具方向。 | 小众/垂直 |  |  | 否 | 否 | 否 | https://www.wordbuddy.ai/ |
| 18_语音_数字人_多模态 | ASR | Automatic Speech Recognition 直译：自动语音识别 | 语音识别 | 术语 | 把语音转文字。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | TTS | Text to Speech 直译：文本到语音 | 语音合成 | 术语 | 把文字转语音。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Voice Agent | 语音智能体 | 语音Agent | 术语 | 通过语音交互和执行任务的Agent。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Realtime API | 实时API | 实时API | 术语 | 支持低延迟语音/多模态交互的API。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Speech-to-Speech | 语音到语音 | 语音到语音 | 术语 | 直接语音输入输出。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Voice Cloning | 声音克隆 | 声音克隆 | 术语 | 模仿某人的声音生成语音。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Speaker Diarization | 说话人分离 | 说话人分离 | 术语 | 区分录音里不同说话人。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Wake Word | 唤醒词 | 唤醒词 | 术语 | 如“Hey Siri”的触发词。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Interruptibility | 可打断性 | 可打断性 | 术语 | 用户插话时AI停止并响应。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Turn-taking | 轮次交替 | 轮次管理 | 术语 | 语音对话中的你说我听节奏。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Digital Human | 数字人 | 数字人 | 术语 | 具有形象、声音和表情的AI人像。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Avatar | 头像/化身 | 数字化身 | 术语 | AI虚拟形象。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Lip Sync | 唇同步 | 口型同步 | 术语 | 让视频人物口型匹配音频。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Talking Head | 说话头 | 说话头像 | 术语 | 生成会说话的人像视频。 |  |  |  |  |  |  |  |
| 18_语音_数字人_多模态 | Multimodal Chat | 多模态聊天 | 多模态对话 | 术语 | 文字、图片、语音、视频混合输入输出。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Code Interpreter | 代码解释器 | 代码解释器 | 术语/工具 | 让AI运行代码分析数据、生成图表和文件。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Python Notebook | Python笔记本 | Python Notebook | 术语/工具 | 交互式数据分析环境。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Jupyter | 木星 | Jupyter | 术语/工具 | 数据分析笔记本工具。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Pandas | 熊猫 | Pandas | 术语/工具 | Python数据表处理库。 |  |  |  |  |  |  |  |
| 19_数据分析AI | NumPy | 数值Python | NumPy | 术语/工具 | Python数值计算库。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Matplotlib | 数学绘图库 | Matplotlib | 术语/工具 | Python绘图库。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Plotly | 品牌名 | Plotly | 术语/工具 | 交互式图表库。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Polars | 极地/品牌名 | Polars | 术语/工具 | 高性能DataFrame库。 |  |  |  |  |  |  |  |
| 19_数据分析AI | DuckDB | 鸭子数据库 | DuckDB | 术语/工具 | 本地分析数据库，适合AI处理表格和数据文件。 |  |  |  |  |  |  |  |
| 19_数据分析AI | EDA | Exploratory Data Analysis 直译：探索性数据分析 | 探索性数据分析 | 术语/工具 | 理解数据结构、分布和异常。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Data Cleaning | 数据清洗 | 数据清洗 | 术语/工具 | 处理缺失、重复、异常值。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Feature Engineering | 特征工程 | 特征工程 | 术语/工具 | 构造模型输入特征。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Forecasting | 预测 | 预测 | 术语/工具 | 基于历史数据预测未来。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Anomaly Detection | 异常检测 | 异常检测 | 术语/工具 | 发现异常数据或行为。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Dashboard | 仪表盘 | 仪表盘 | 术语/工具 | 可视化业务指标。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Power BI | 强力商业智能 | Power BI | 术语/工具 | 微软BI工具。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Tableau | 画板 | Tableau | 术语/工具 | BI可视化工具。 |  |  |  |  |  |  |  |
| 19_数据分析AI | Metabase | 元数据库 | Metabase | 术语/工具 | 开源BI工具。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | Training | 训练 | 训练 | 术语 | 用数据更新模型参数。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | Pretraining | 预训练 | 预训练 | 术语 | 在大规模数据上训练基座模型。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | Fine-tuning | 微调 | 微调 | 术语 | 用特定数据继续训练模型，使其适合特定任务。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | SFT | Supervised Fine-tuning 直译：监督微调 | 监督微调 | 术语 | 用标注问答或指令数据训练模型。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | RLHF | Reinforcement Learning from Human Feedback 直译：人类反馈强化学习 | 人类反馈强化学习 | 术语 | 用人类偏好训练模型更符合人意图。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | DPO | Direct Preference Optimization 直译：直接偏好优化 | DPO | 术语 | 直接用偏好数据优化模型。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | LoRA | Low-Rank Adaptation 直译：低秩适配 | LoRA | 术语 | 轻量微调方法，图像模型和LLM都常见。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | QLoRA | 量化LoRA | QLoRA | 术语 | 在量化模型上进行LoRA微调，省显存。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | Synthetic Data | 合成数据 | 合成数据 | 术语 | 由模型生成的数据。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | Instruction Dataset | 指令数据集 | 指令数据集 | 术语 | 用于训练模型听指令的数据。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | Preference Dataset | 偏好数据集 | 偏好数据集 | 术语 | 用于训练偏好排序的数据。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | Data Contamination | 数据污染 | 数据污染 | 术语 | 测试题进入训练集，导致评测失真。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | Data Poisoning | 数据投毒 | 数据投毒 | 术语 | 恶意数据破坏模型行为。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | Overfitting | 过拟合 | 过拟合 | 术语 | 模型记住训练数据但泛化差。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | Distillation | 蒸馏 | 模型蒸馏 | 术语 | 用大模型能力训练小模型。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | Alignment | 对齐 | 对齐 | 术语 | 让模型行为符合人类意图和规则。 |  |  |  |  |  |  |  |
| 20_训练_微调_数据集 | Post-training | 后训练 | 后训练 | 术语 | 预训练后进行指令、安全、偏好优化。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | AI Native | AI原生 | AI原生 | 术语 | 产品从底层设计就围绕AI能力。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | AI-first Product | AI优先产品 | AI优先产品 | 术语 | 优先用AI重新设计功能和流程。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | Copilot | 副驾驶 | 副驾驶式AI | 术语 | 辅助人工作，人在主导。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | Autopilot | 自动驾驶 | 自动驾驶式AI | 术语 | AI主动完成任务，人监督。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | AI SaaS | AI软件即服务 | AI SaaS | 术语 | 基于订阅或按量计费的AI软件。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | Vertical AI | 垂直AI | 垂直行业AI | 术语 | 面向特定行业或场景的AI。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | Horizontal AI | 横向AI | 通用AI | 术语 | 跨行业通用工具。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | AI Wrapper | AI包装器 | AI壳产品 | 术语 | 包装现有模型形成产品，技术壁垒较低。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | Data Flywheel | 数据飞轮 | 数据飞轮 | 术语 | 用户数据持续改进产品。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | Agent Marketplace | 智能体市场 | Agent市场 | 术语 | 交易、分发、发现Agent的平台。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | Skill Marketplace | 技能市场 | Skill市场 | 术语 | 分发AI技能包的平台。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | Prompt Marketplace | 提示市场 | 提示词市场 | 术语 | 交易提示词模板的平台。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | Inference Cost | 推理成本 | 推理成本 | 术语 | 模型运行成本。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | BYOK | Bring Your Own Key 直译：自带钥匙 | 自带API Key | 术语 | 用户用自己的模型API Key。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | BYOM | Bring Your Own Model 直译：自带模型 | 自带模型 | 术语 | 用户接入自己的模型。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | White-label AI | 白标AI | 白标AI | 术语 | 把AI产品换品牌卖给客户。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | Private Deployment | 私有部署 | 私有化部署 | 术语 | 部署到企业自己的服务器或云环境。 |  |  |  |  |  |  |  |
| 21_AI产品_商业模式 | On-premise | 本地机房 | 本地部署 | 术语 | 部署在客户自己的机房。 |  |  |  |  |  |  |  |
| 22_开发_部署基础设施 | VS Code | 视觉工作室代码 | VS Code | 软件/IDE | 主流代码编辑器，AI插件生态丰富。 | 国际顶流 |  |  | 部分 | 是 | 是 | https://code.visualstudio.com/ |
| 22_开发_部署基础设施 | Git | 品牌名 | Git | 开源项目/版本控制 | 版本控制工具，AI写代码必须配合回滚和分支。 | SS 顶流 | 54000 | 26000 | 是 | 是 | 是 | https://github.com/git/git |
| 22_开发_部署基础设施 | GitHub | Git中心 | GitHub | 平台/代码托管 | 代码托管、Issue、PR、Actions、开源生态平台。 | 国际顶流 |  |  | 否 | 否 | 是 | https://github.com/ |
| 22_开发_部署基础设施 | GitHub Actions | GitHub动作 | GitHub Actions | 平台/CI/CD | GitHub CI/CD自动化。 | 国际顶流 |  |  | 否 | 否 | 是 | https://github.com/features/actions |
| 22_开发_部署基础设施 | Docker | 码头工人 | Docker | 开源项目/容器 | 容器化部署工具，便于迁移和一键部署AI项目。 | 国际顶流 |  |  | 部分 | 是 | 是 | https://github.com/docker |
| 22_开发_部署基础设施 | Docker Compose | Docker编排 | Docker Compose | 开源项目/容器编排 | 多容器编排，适合Dify、n8n、数据库部署。 | S 高热 | 35000 | 5400 | 是 | 是 | 是 | https://github.com/docker/compose |
| 22_开发_部署基础设施 | Dev Container | 开发容器 | Dev Container | 规范/工具 | 把项目开发环境容器化，方便AI和多电脑复现。 | 高热 |  |  | 部分 | 是 | 是 | https://containers.dev/ |
| 22_开发_部署基础设施 | Vercel | 品牌名 | Vercel | 平台/部署 | 前端/Next.js部署平台，适合AI Web应用。 | 国际顶流 |  |  | 否 | 否 | 是 | https://vercel.com/ |
| 22_开发_部署基础设施 | Netlify | 品牌名 | Netlify | 平台/部署 | 前端部署和Serverless平台。 | 国际高热 |  |  | 否 | 否 | 部分 | https://www.netlify.com/ |
| 22_开发_部署基础设施 | Cloudflare Workers | Cloudflare工人 | Cloudflare Workers | 平台/边缘计算 | 边缘函数部署平台。 | 国际顶流 |  |  | 否 | 否 | 部分 | https://workers.cloudflare.com/ |
| 22_开发_部署基础设施 | Supabase | 超级基地 | Supabase | 开源项目/后端平台 | 开源后端即服务，Postgres/Auth/Storage/Edge Functions。 | SS 顶流 | 88000 | 9600 | 是 | 部分 | 是 | https://github.com/supabase/supabase |
| 22_开发_部署基础设施 | Firebase | 火基地 | Firebase | 平台/后端 | Google后端即服务。 | 国际顶流 |  |  | 否 | 否 | 部分 | https://firebase.google.com/ |
| 22_开发_部署基础设施 | PocketBase | 口袋基地 | PocketBase | 开源项目/后端 | 轻量单文件后端。 | SS 顶流 | 51000 | 2500 | 是 | 是 | 是 | https://github.com/pocketbase/pocketbase |
| 22_开发_部署基础设施 | Appwrite | 应用写入 | Appwrite | 开源项目/后端 | 开源后端平台。 | SS 顶流 | 51000 | 4600 | 是 | 是 | 是 | https://github.com/appwrite/appwrite |
| 22_开发_部署基础设施 | Prisma | 棱镜 | Prisma | 开源项目/ORM | TypeScript ORM。 | S 高热 | 45000 | 1600 | 是 | 是 | 是 | https://github.com/prisma/prisma |
| 22_开发_部署基础设施 | Drizzle | 毛毛雨 | Drizzle ORM | 开源项目/ORM | TypeScript ORM，轻量、类型友好。 | S 高热 | 30000 | 900 | 是 | 是 | 是 | https://github.com/drizzle-team/drizzle-orm |
| 22_开发_部署基础设施 | Postman | 邮差 | Postman | 平台/API工具 | API测试工具。 | 国际顶流 |  |  | 否 | 否 | 部分 | https://www.postman.com/ |
| 22_开发_部署基础设施 | OpenAPI | 开放API | OpenAPI | 规范/API | REST API规范，可生成文档、SDK和MCP适配。 | 高热 |  |  | 是 | 是 | 是 | https://www.openapis.org/ |
| 22_开发_部署基础设施 | REST API | 表征状态转移API | REST API | 术语/API | 最常见Web API风格。 | 高热 |  |  |  |  | 是 |  |
| 22_开发_部署基础设施 | GraphQL | 图查询语言 | GraphQL | 开源项目/API | API查询语言。 | S 高热 | 21000 | 2100 | 是 | 是 | 部分 | https://github.com/graphql/graphql-js |
| 22_开发_部署基础设施 | WebSocket | 网络套接字 | WebSocket | 协议 | 双向实时通信协议。 | 高热 |  |  |  |  | 部分 |  |
| 22_开发_部署基础设施 | SSE | Server-Sent Events 直译：服务器发送事件 | SSE | 协议 | 服务端向前端推送流式事件，AI流式输出常用。 | 高热 |  |  |  |  | 是 |  |
| 22_开发_部署基础设施 | Redis | 品牌名 | Redis | 开源项目/缓存 | 缓存、队列、会话、轻量向量搜索场景常用。 | SS 顶流 | 69000 | 24000 | 是 | 是 | 部分 | https://github.com/redis/redis |
| 22_开发_部署基础设施 | PostgreSQL | Postgres数据库 | PostgreSQL | 开源项目/数据库 | 开源关系数据库，AI应用常用主数据库。 | A 中高热 | 17000 | 5300 | 是 | 是 | 部分 | https://github.com/postgres/postgres |
| 22_开发_部署基础设施 | SQLite | 小型SQL | SQLite | 开源项目/数据库 | 轻量本地数据库，适合本地AI工具。 | 国际顶流 |  |  | 是 | 是 | 部分 | https://sqlite.org/ |