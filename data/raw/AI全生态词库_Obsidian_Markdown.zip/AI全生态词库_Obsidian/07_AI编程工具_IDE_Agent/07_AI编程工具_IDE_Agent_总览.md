# 07_AI编程工具_IDE_Agent

- 词条数量：34
- 更新时间：2026-06-21
- 用法：先看表格总览，再在下方词条内记录教程、试用经验、接入步骤。

## 快速总览

| 原名 | 直译 | 常用中文名 | 类型 | 热度 | Stars | Forks | 开源 | 本地部署 | 适合Codex | 来源 |
|---|---|---|---|---|---:|---:|---|---|---|---|
| OpenAI Codex | 代码抄本/法典 | Codex | 平台/Agent | 国际顶流 |  |  | 否 | 否 | 是 | https://openai.com/codex |
| Claude Code | Claude代码 | Claude Code | 平台/Agent | 国际顶流 |  |  | 否 | 否 | 是 | https://github.com/anthropics/claude-code |
| Cursor | 光标 | Cursor | 平台/IDE | 国际顶流 |  |  | 否 | 否 | 是 | https://cursor.com/ |
| Windsurf | 风帆冲浪 | Windsurf | 平台/IDE | 国际高热 |  |  | 否 | 否 | 是 | https://windsurf.com/ |
| GitHub Copilot | GitHub副驾驶 | GitHub Copilot | 平台/IDE插件 | 国际顶流 |  |  | 否 | 否 | 是 | https://github.com/features/copilot |
| Devin | 品牌名 | Devin | 平台/Agent | 国际高热 |  |  | 否 | 否 | 部分 | https://devin.ai/ |
| Replit Agent | Replit智能体 | Replit Agent | 平台/应用生成 | 国际高热 |  |  | 否 | 否 | 部分 | https://replit.com/ai |
| Lovable | 可爱/值得爱 | Lovable | 平台/应用生成 | 国际高热 |  |  | 否 | 否 | 部分 | https://lovable.dev/ |
| Bolt.new | 螺栓 | Bolt.new | 平台/应用生成 | 国际高热 |  |  | 否 | 否 | 部分 | https://bolt.new/ |
| OpenAI Codex | 代码抄本/法典 | Codex | 平台/Agent | 国际顶流 |  |  | 否 | 否 | 是 | https://openai.com/codex |
| Claude Code | Claude代码 | Claude Code | 平台/Agent | 国际顶流 |  |  | 否 | 否 | 是 | https://github.com/anthropics/claude-code |
| Cursor | 光标 | Cursor | 平台/IDE | 国际顶流 |  |  | 否 | 否 | 是 | https://cursor.com/ |
| Windsurf | 风帆冲浪 | Windsurf | 平台/IDE | 国际高热 |  |  | 否 | 否 | 是 | https://windsurf.com/ |
| GitHub Copilot | GitHub副驾驶 | GitHub Copilot | 平台/IDE插件 | 国际顶流 |  |  | 否 | 否 | 是 | https://github.com/features/copilot |
| Devin | 品牌名 | Devin | 平台/Agent | 国际高热 |  |  | 否 | 否 | 部分 | https://devin.ai/ |
| Replit Agent | Replit智能体 | Replit Agent | 平台/应用生成 | 国际高热 |  |  | 否 | 否 | 部分 | https://replit.com/ai |
| Lovable | 可爱/值得爱 | Lovable | 平台/应用生成 | 国际高热 |  |  | 否 | 否 | 部分 | https://lovable.dev/ |
| Bolt.new | 螺栓 | Bolt.new | 平台/应用生成 | 国际高热 |  |  | 否 | 否 | 部分 | https://bolt.new/ |
| bolt.diy | 螺栓DIY | bolt.diy | 开源项目 | A 中高热 | 19000 | 2300 | 是 | 是 | 是 | https://github.com/stackblitz-labs/bolt.diy |
| opencode | 开放代码 | opencode | 开源项目 | SSS 超顶流 | 177000 | 21600 | 是 | 是 | 是 | https://github.com/sst/opencode |
| Gemini CLI | Gemini命令行 | Gemini CLI | 开源项目 | SSS 超顶流 | 105000 | 14100 | 是 | 是 | 是 | https://github.com/google-gemini/gemini-cli |
| OpenHands | 开放之手 | OpenHands | 开源项目 | SS 顶流 | 77900 | 9900 | 是 | 是 | 是 | https://github.com/All-Hands-AI/OpenHands |
| Cline | 品牌名 | Cline | 开源项目 | SS 顶流 | 63600 | 6700 | 是 | 是 | 是 | https://github.com/cline/cline |
| Aider | 帮手 | Aider | 开源项目 | S 高热 | 46500 | 4600 | 是 | 是 | 是 | https://github.com/Aider-AI/aider |
| Continue | 继续 | Continue | 开源项目 | S 高热 | 34200 | 4800 | 是 | 是 | 是 | https://github.com/continuedev/continue |
| Tabby | 虎斑猫/品牌名 | Tabby | 开源项目 | S 高热 | 33600 | 1800 | 是 | 是 | 是 | https://github.com/TabbyML/tabby |
| Qwen Code | 通义代码 | Qwen Code | 开源项目 | S 高热 | 25400 | 2500 | 是 | 是 | 是 | https://github.com/QwenLM/qwen-code |
| Roo Code | Roo代码 | Roo Code | 开源项目 | S 高热 | 24200 | 3300 | 是 | 是 | 部分 | https://github.com/RooCodeInc/Roo-Code |
| CodeBuddy | 代码伙伴 | 腾讯云CodeBuddy | 平台/IDE | 国内高热 |  |  | 否 | 否 | 部分 | https://www.codebuddy.ai/ |
| Trae | 品牌名 | Trae | 平台/IDE | 国内高热 |  |  | 否 | 否 | 是 | https://www.trae.ai/ |
| Sourcegraph Cody | 源码图 Cody | Cody | 平台/IDE插件 | 国际中高热 |  |  | 部分 | 部分 | 是 | https://sourcegraph.com/cody |
| Amazon Q Developer | 亚马逊Q开发者 | Amazon Q Developer | 平台/云助手 | 国际高热 |  |  | 否 | 否 | 部分 | https://aws.amazon.com/q/developer/ |
| Tabnine | 品牌名 | Tabnine | 平台/IDE插件 | 国际中高热 |  |  | 否 | 部分 | 是 | https://www.tabnine.com/ |
| v0 | 零版本 | v0 | 平台/UI生成 | 国际高热 |  |  | 否 | 否 | 部分 | https://v0.dev/ |

## 详细词条

## OpenAI Codex

> OpenAI编程Agent，可读写代码、跑测试、处理工程任务。

| 字段 | 内容 |
|---|---|
| 原名 | OpenAI Codex |
| 直译 | 代码抄本/法典 |
| 常用中文名 | Codex |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/Agent |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://openai.com/codex |
| 热度等级 | 国际顶流 |
| 国际热度 | 国际顶流 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 闭源平台，注意权限和费用。 |
| 数据来源URL | https://openai.com/codex |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Claude Code

> Anthropic的终端/IDE编程Agent，适合大型代码库和自动化开发。

| 字段 | 内容 |
|---|---|
| 原名 | Claude Code |
| 直译 | Claude代码 |
| 常用中文名 | Claude Code |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/Agent |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/anthropics/claude-code |
| 代表GitHub仓库 | anthropics/claude-code |
| 热度等级 | 国际顶流 |
| 国际热度 | 国际顶流 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 依赖Claude账号和额度。 |
| 数据来源URL | https://github.com/anthropics/claude-code |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Cursor

> AI IDE，主打代码库理解、Agent和计划/执行模式。

| 字段 | 内容 |
|---|---|
| 原名 | Cursor |
| 直译 | 光标 |
| 常用中文名 | Cursor |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/IDE |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://cursor.com/ |
| 热度等级 | 国际顶流 |
| 国际热度 | 国际顶流 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 闭源商业工具。 |
| 数据来源URL | https://cursor.com/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Windsurf

> AI IDE，Cascade工作流是其核心亮点。

| 字段 | 内容 |
|---|---|
| 原名 | Windsurf |
| 直译 | 风帆冲浪 |
| 常用中文名 | Windsurf |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/IDE |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://windsurf.com/ |
| 热度等级 | 国际高热 |
| 国际热度 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 商业工具。 |
| 数据来源URL | https://windsurf.com/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## GitHub Copilot

> GitHub/微软AI编程助手，覆盖补全、聊天、Agent、PR流程。

| 字段 | 内容 |
|---|---|
| 原名 | GitHub Copilot |
| 直译 | GitHub副驾驶 |
| 常用中文名 | GitHub Copilot |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/IDE插件 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/features/copilot |
| 热度等级 | 国际顶流 |
| 国际热度 | 国际顶流 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 企业使用注意代码和隐私政策。 |
| 数据来源URL | https://github.com/features/copilot |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Devin

> Cognition的软件工程Agent，偏自动完成工程任务。

| 字段 | 内容 |
|---|---|
| 原名 | Devin |
| 直译 | 品牌名 |
| 常用中文名 | Devin |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/Agent |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://devin.ai/ |
| 热度等级 | 国际高热 |
| 国际热度 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 商业工具，成本较高。 |
| 数据来源URL | https://devin.ai/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Replit Agent

> 在线生成、开发、部署应用的AI Agent。

| 字段 | 内容 |
|---|---|
| 原名 | Replit Agent |
| 直译 | Replit智能体 |
| 常用中文名 | Replit Agent |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/应用生成 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://replit.com/ai |
| 热度等级 | 国际高热 |
| 国际热度 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 在线平台，适合快速原型。 |
| 数据来源URL | https://replit.com/ai |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Lovable

> Prompt-to-App工具，用自然语言生成Web应用。

| 字段 | 内容 |
|---|---|
| 原名 | Lovable |
| 直译 | 可爱/值得爱 |
| 常用中文名 | Lovable |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/应用生成 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://lovable.dev/ |
| 热度等级 | 国际高热 |
| 国际热度 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 适合原型，复杂项目仍需人工验收。 |
| 数据来源URL | https://lovable.dev/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Bolt.new

> StackBlitz的浏览器应用生成工具。

| 字段 | 内容 |
|---|---|
| 原名 | Bolt.new |
| 直译 | 螺栓 |
| 常用中文名 | Bolt.new |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/应用生成 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://bolt.new/ |
| 热度等级 | 国际高热 |
| 国际热度 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 浏览器在线开发。 |
| 数据来源URL | https://bolt.new/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## OpenAI Codex

> OpenAI编程Agent，可读写代码、跑测试、处理工程任务。

| 字段 | 内容 |
|---|---|
| 原名 | OpenAI Codex |
| 直译 | 代码抄本/法典 |
| 常用中文名 | Codex |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/Agent |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://openai.com/codex |
| 热度等级 | 国际顶流 |
| 国际热度 | 国际顶流 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 闭源平台，注意权限和费用。 |
| 数据来源URL | https://openai.com/codex |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Claude Code

> Anthropic的终端/IDE编程Agent，适合大型代码库和自动化开发。

| 字段 | 内容 |
|---|---|
| 原名 | Claude Code |
| 直译 | Claude代码 |
| 常用中文名 | Claude Code |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/Agent |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/anthropics/claude-code |
| 代表GitHub仓库 | anthropics/claude-code |
| 热度等级 | 国际顶流 |
| 国际热度 | 国际顶流 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 依赖Claude账号和额度。 |
| 数据来源URL | https://github.com/anthropics/claude-code |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Cursor

> AI IDE，主打代码库理解、Agent和计划/执行模式。

| 字段 | 内容 |
|---|---|
| 原名 | Cursor |
| 直译 | 光标 |
| 常用中文名 | Cursor |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/IDE |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://cursor.com/ |
| 热度等级 | 国际顶流 |
| 国际热度 | 国际顶流 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 闭源商业工具。 |
| 数据来源URL | https://cursor.com/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Windsurf

> AI IDE，Cascade工作流是其核心亮点。

| 字段 | 内容 |
|---|---|
| 原名 | Windsurf |
| 直译 | 风帆冲浪 |
| 常用中文名 | Windsurf |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/IDE |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://windsurf.com/ |
| 热度等级 | 国际高热 |
| 国际热度 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 商业工具。 |
| 数据来源URL | https://windsurf.com/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## GitHub Copilot

> GitHub/微软AI编程助手，覆盖补全、聊天、Agent、PR流程。

| 字段 | 内容 |
|---|---|
| 原名 | GitHub Copilot |
| 直译 | GitHub副驾驶 |
| 常用中文名 | GitHub Copilot |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/IDE插件 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/features/copilot |
| 热度等级 | 国际顶流 |
| 国际热度 | 国际顶流 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 企业使用注意代码和隐私政策。 |
| 数据来源URL | https://github.com/features/copilot |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Devin

> Cognition的软件工程Agent，偏自动完成工程任务。

| 字段 | 内容 |
|---|---|
| 原名 | Devin |
| 直译 | 品牌名 |
| 常用中文名 | Devin |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/Agent |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://devin.ai/ |
| 热度等级 | 国际高热 |
| 国际热度 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 商业工具，成本较高。 |
| 数据来源URL | https://devin.ai/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Replit Agent

> 在线生成、开发、部署应用的AI Agent。

| 字段 | 内容 |
|---|---|
| 原名 | Replit Agent |
| 直译 | Replit智能体 |
| 常用中文名 | Replit Agent |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/应用生成 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://replit.com/ai |
| 热度等级 | 国际高热 |
| 国际热度 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 在线平台，适合快速原型。 |
| 数据来源URL | https://replit.com/ai |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Lovable

> Prompt-to-App工具，用自然语言生成Web应用。

| 字段 | 内容 |
|---|---|
| 原名 | Lovable |
| 直译 | 可爱/值得爱 |
| 常用中文名 | Lovable |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/应用生成 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://lovable.dev/ |
| 热度等级 | 国际高热 |
| 国际热度 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 适合原型，复杂项目仍需人工验收。 |
| 数据来源URL | https://lovable.dev/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Bolt.new

> StackBlitz的浏览器应用生成工具。

| 字段 | 内容 |
|---|---|
| 原名 | Bolt.new |
| 直译 | 螺栓 |
| 常用中文名 | Bolt.new |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/应用生成 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://bolt.new/ |
| 热度等级 | 国际高热 |
| 国际热度 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 浏览器在线开发。 |
| 数据来源URL | https://bolt.new/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## bolt.diy

> Bolt的开源版本，可连接多家模型和Ollama。

| 字段 | 内容 |
|---|---|
| 原名 | bolt.diy |
| 直译 | 螺栓DIY |
| 常用中文名 | bolt.diy |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/stackblitz-labs/bolt.diy |
| 代表GitHub仓库 | stackblitz-labs/bolt.diy |
| GitHub Stars(约) | 19000 |
| Forks(约) | 2300 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 部分 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 开源生态快，需关注维护状态。 |
| 数据来源URL | https://github.com/stackblitz-labs/bolt.diy |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## opencode

> 开源终端/IDE coding agent，支持多模型和并行会话。

| 字段 | 内容 |
|---|---|
| 原名 | opencode |
| 直译 | 开放代码 |
| 常用中文名 | opencode |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/sst/opencode |
| 代表GitHub仓库 | sst/opencode |
| GitHub Stars(约) | 177000 |
| Forks(约) | 21600 |
| 热度等级 | SSS 超顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 高热项目，需验证实际工作流。 |
| 数据来源URL | https://github.com/sst/opencode |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Gemini CLI

> Google开源终端Agent，把Gemini接入开发者命令行。

| 字段 | 内容 |
|---|---|
| 原名 | Gemini CLI |
| 直译 | Gemini命令行 |
| 常用中文名 | Gemini CLI |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/google-gemini/gemini-cli |
| 代表GitHub仓库 | google-gemini/gemini-cli |
| GitHub Stars(约) | 105000 |
| Forks(约) | 14100 |
| 热度等级 | SSS 超顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 部分 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 依赖Google模型生态。 |
| 数据来源URL | https://github.com/google-gemini/gemini-cli |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## OpenHands

> 开源软件工程Agent，可理解为自托管Devin方向。

| 字段 | 内容 |
|---|---|
| 原名 | OpenHands |
| 直译 | 开放之手 |
| 常用中文名 | OpenHands |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/All-Hands-AI/OpenHands |
| 代表GitHub仓库 | All-Hands-AI/OpenHands |
| GitHub Stars(约) | 77900 |
| Forks(约) | 9900 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 部署和沙箱配置要谨慎。 |
| 数据来源URL | https://github.com/All-Hands-AI/OpenHands |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Cline

> VS Code开源coding agent，支持MCP、终端、浏览器等。

| 字段 | 内容 |
|---|---|
| 原名 | Cline |
| 直译 | 品牌名 |
| 常用中文名 | Cline |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/cline/cline |
| 代表GitHub仓库 | cline/cline |
| GitHub Stars(约) | 63600 |
| Forks(约) | 6700 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 注意权限模式和成本。 |
| 数据来源URL | https://github.com/cline/cline |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Aider

> 终端AI结对编程工具，适合已有仓库改代码。

| 字段 | 内容 |
|---|---|
| 原名 | Aider |
| 直译 | 帮手 |
| 常用中文名 | Aider |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/Aider-AI/aider |
| 代表GitHub仓库 | Aider-AI/aider |
| GitHub Stars(约) | 46500 |
| Forks(约) | 4600 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 适合工程师。 |
| 数据来源URL | https://github.com/Aider-AI/aider |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Continue

> 开源AI代码助手，可接本地/云模型，支持VS Code/JetBrains。

| 字段 | 内容 |
|---|---|
| 原名 | Continue |
| 直译 | 继续 |
| 常用中文名 | Continue |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/continuedev/continue |
| 代表GitHub仓库 | continuedev/continue |
| GitHub Stars(约) | 34200 |
| Forks(约) | 4800 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 适合私有化和本地模型。 |
| 数据来源URL | https://github.com/continuedev/continue |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Tabby

> 自托管AI编程助手，类似私有Copilot。

| 字段 | 内容 |
|---|---|
| 原名 | Tabby |
| 直译 | 虎斑猫/品牌名 |
| 常用中文名 | Tabby |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/TabbyML/tabby |
| 代表GitHub仓库 | TabbyML/tabby |
| GitHub Stars(约) | 33600 |
| Forks(约) | 1800 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 部分 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 适合团队私有代码补全。 |
| 数据来源URL | https://github.com/TabbyML/tabby |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Qwen Code

> Qwen生态终端coding agent。

| 字段 | 内容 |
|---|---|
| 原名 | Qwen Code |
| 直译 | 通义代码 |
| 常用中文名 | Qwen Code |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/QwenLM/qwen-code |
| 代表GitHub仓库 | QwenLM/qwen-code |
| GitHub Stars(约) | 25400 |
| Forks(约) | 2500 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 部分 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 中文和Qwen模型生态友好。 |
| 数据来源URL | https://github.com/QwenLM/qwen-code |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Roo Code

> VS Code coding agent生态项目，需注意归档/维护状态。

| 字段 | 内容 |
|---|---|
| 原名 | Roo Code |
| 直译 | Roo代码 |
| 常用中文名 | Roo Code |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 开源项目 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://github.com/RooCodeInc/Roo-Code |
| 代表GitHub仓库 | RooCodeInc/Roo-Code |
| GitHub Stars(约) | 24200 |
| Forks(约) | 3300 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 否 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 已归档/维护风险。 |
| 数据来源URL | https://github.com/RooCodeInc/Roo-Code |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## CodeBuddy

> 腾讯云相关AI编程助手。

| 字段 | 内容 |
|---|---|
| 原名 | CodeBuddy |
| 直译 | 代码伙伴 |
| 常用中文名 | 腾讯云CodeBuddy |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/IDE |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://www.codebuddy.ai/ |
| 热度等级 | 国内高热 |
| 国内热度 | 国内高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 国内生态工具。 |
| 数据来源URL | https://www.codebuddy.ai/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Trae

> 字节系AI IDE/编程工具方向。

| 字段 | 内容 |
|---|---|
| 原名 | Trae |
| 直译 | 品牌名 |
| 常用中文名 | Trae |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/IDE |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://www.trae.ai/ |
| 热度等级 | 国内高热 |
| 国内热度 | 国内高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 部分 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 工具能力快速变化。 |
| 数据来源URL | https://www.trae.ai/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Sourcegraph Cody

> 面向代码库理解的AI工具。

| 字段 | 内容 |
|---|---|
| 原名 | Sourcegraph Cody |
| 直译 | 源码图 Cody |
| 常用中文名 | Cody |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/IDE插件 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://sourcegraph.com/cody |
| 热度等级 | 国际中高热 |
| 国际热度 | 国际中高热 |
| 是否开源 | 部分 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 适合大型代码库搜索。 |
| 数据来源URL | https://sourcegraph.com/cody |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Amazon Q Developer

> AWS编程和云开发助手。

| 字段 | 内容 |
|---|---|
| 原名 | Amazon Q Developer |
| 直译 | 亚马逊Q开发者 |
| 常用中文名 | Amazon Q Developer |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/云助手 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://aws.amazon.com/q/developer/ |
| 热度等级 | 国际高热 |
| 国际热度 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 适合AWS生态。 |
| 数据来源URL | https://aws.amazon.com/q/developer/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Tabnine

> AI代码补全工具。

| 字段 | 内容 |
|---|---|
| 原名 | Tabnine |
| 直译 | 品牌名 |
| 常用中文名 | Tabnine |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/IDE插件 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://www.tabnine.com/ |
| 热度等级 | 国际中高热 |
| 国际热度 | 国际中高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 部分 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 企业代码隐私方案较多。 |
| 数据来源URL | https://www.tabnine.com/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## v0

> Vercel的AI前端/UI生成工具。

| 字段 | 内容 |
|---|---|
| 原名 | v0 |
| 直译 | 零版本 |
| 常用中文名 | v0 |
| 类别 | 07_AI编程工具_IDE_Agent |
| 类型 | 平台/UI生成 |
| 能给AI起到什么帮助 | 提升AI编程、代码理解、自动修改、测试和部署效率。 |
| 代表平台/官网 | https://v0.dev/ |
| 热度等级 | 国际高热 |
| 国际热度 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,CodingAgent,VibeCoding,IDE |
| 风险/备注 | 前端UI生成强。 |
| 数据来源URL | https://v0.dev/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：
