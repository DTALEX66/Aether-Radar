# 14_自动化_Workflow_低代码

- 词条数量：12
- 更新时间：2026-06-21
- 用法：先看表格总览，再在下方词条内记录教程、试用经验、接入步骤。

## 快速总览

| 原名 | 直译 | 常用中文名 | 类型 | 热度 | Stars | Forks | 开源 | 本地部署 | 适合Codex | 来源 |
|---|---|---|---|---|---:|---:|---|---|---|---|
| n8n | 品牌名 | n8n | 开源项目/自动化 | SS 顶流 | 90000 | 25000 | 是 | 是 | 是 | https://github.com/n8n-io/n8n |
| Dify Workflow | Dify工作流 | Dify工作流 | 功能/工作流 | SSS 超顶流 | 145982 | 22959 | 是 | 是 | 是 | https://dify.ai/ |
| Flowise | 流式智能 | Flowise | 开源项目/工作流 | SS 顶流 | 53800 | 24600 | 是 | 是 | 是 | https://github.com/FlowiseAI/Flowise |
| Langflow | 语言流 | Langflow | 开源项目/低代码 | SSS 超顶流 | 150000 | 9300 | 是 | 是 | 是 | https://github.com/langflow-ai/langflow |
| Zapier | 品牌名 | Zapier | 平台/自动化 |  |  |  | 否 | 否 | 部分 | https://zapier.com/ |
| Make | 制作 | Make | 平台/自动化 |  |  |  | 否 | 否 | 部分 | https://www.make.com/ |
| Pipedream | 管道梦 | Pipedream | 平台/自动化 |  |  |  | 部分 | 否 | 部分 | https://pipedream.com/ |
| Activepieces | 活动组件 | Activepieces | 开源项目/自动化 | A 中高热 | 18000 | 2200 | 是 | 是 | 是 | https://github.com/activepieces/activepieces |
| Node-RED | 节点红 | Node-RED | 开源项目/自动化 | S 高热 | 20000 | 3400 | 是 | 是 | 部分 | https://github.com/node-red/node-red |
| Temporal | 时间性的 | Temporal | 开源项目/工作流引擎 | A 中高热 | 15000 | 2000 | 是 | 是 | 部分 | https://github.com/temporalio/temporal |
| Airflow | 气流 | Apache Airflow | 开源项目/数据工作流 | S 高热 | 40000 | 14000 | 是 | 是 | 部分 | https://github.com/apache/airflow |
| Prefect | 长官/完美者 | Prefect | 开源项目/数据工作流 | A 中高热 | 17000 | 1700 | 是 | 是 | 部分 | https://github.com/PrefectHQ/prefect |

## 详细词条

## n8n

> 可自托管自动化工作流平台，支持AI Agent节点和大量连接器。

| 字段 | 内容 |
|---|---|
| 原名 | n8n |
| 直译 | 品牌名 |
| 常用中文名 | n8n |
| 类别 | 14_自动化_Workflow_低代码 |
| 类型 | 开源项目/自动化 |
| 能给AI起到什么帮助 | 把AI能力接入业务流程、定时任务、API和多工具自动化。 |
| 代表平台/官网 | https://github.com/n8n-io/n8n |
| 代表GitHub仓库 | n8n-io/n8n |
| GitHub Stars(约) | 90000 |
| Forks(约) | 25000 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 自动化,工作流,低代码,AgenticWorkflow |
| 风险/备注 | 自动化要做好权限、日志、重试和失败处理。 |
| 数据来源URL | https://github.com/n8n-io/n8n |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Dify Workflow

> 在Dify中编排LLM、RAG、工具和业务流程。

| 字段 | 内容 |
|---|---|
| 原名 | Dify Workflow |
| 直译 | Dify工作流 |
| 常用中文名 | Dify工作流 |
| 类别 | 14_自动化_Workflow_低代码 |
| 类型 | 功能/工作流 |
| 能给AI起到什么帮助 | 把AI能力接入业务流程、定时任务、API和多工具自动化。 |
| 代表平台/官网 | https://dify.ai/ |
| 代表GitHub仓库 | langgenius/dify |
| GitHub Stars(约) | 145982 |
| Forks(约) | 22959 |
| 热度等级 | SSS 超顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 自动化,工作流,低代码,AgenticWorkflow |
| 风险/备注 | 自动化要做好权限、日志、重试和失败处理。 |
| 数据来源URL | https://dify.ai/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Flowise

> 拖拽式AI workflow和Agent构建。

| 字段 | 内容 |
|---|---|
| 原名 | Flowise |
| 直译 | 流式智能 |
| 常用中文名 | Flowise |
| 类别 | 14_自动化_Workflow_低代码 |
| 类型 | 开源项目/工作流 |
| 能给AI起到什么帮助 | 把AI能力接入业务流程、定时任务、API和多工具自动化。 |
| 代表平台/官网 | https://github.com/FlowiseAI/Flowise |
| 代表GitHub仓库 | FlowiseAI/Flowise |
| GitHub Stars(约) | 53800 |
| Forks(约) | 24600 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 自动化,工作流,低代码,AgenticWorkflow |
| 风险/备注 | 自动化要做好权限、日志、重试和失败处理。 |
| 数据来源URL | https://github.com/FlowiseAI/Flowise |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Langflow

> 低代码构建Agent、RAG和MCP Server。

| 字段 | 内容 |
|---|---|
| 原名 | Langflow |
| 直译 | 语言流 |
| 常用中文名 | Langflow |
| 类别 | 14_自动化_Workflow_低代码 |
| 类型 | 开源项目/低代码 |
| 能给AI起到什么帮助 | 把AI能力接入业务流程、定时任务、API和多工具自动化。 |
| 代表平台/官网 | https://github.com/langflow-ai/langflow |
| 代表GitHub仓库 | langflow-ai/langflow |
| GitHub Stars(约) | 150000 |
| Forks(约) | 9300 |
| 热度等级 | SSS 超顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 自动化,工作流,低代码,AgenticWorkflow |
| 风险/备注 | 自动化要做好权限、日志、重试和失败处理。 |
| 数据来源URL | https://github.com/langflow-ai/langflow |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Zapier

> 自动化连接器平台。

| 字段 | 内容 |
|---|---|
| 原名 | Zapier |
| 直译 | 品牌名 |
| 常用中文名 | Zapier |
| 类别 | 14_自动化_Workflow_低代码 |
| 类型 | 平台/自动化 |
| 能给AI起到什么帮助 | 把AI能力接入业务流程、定时任务、API和多工具自动化。 |
| 代表平台/官网 | https://zapier.com/ |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 自动化,工作流,低代码,AgenticWorkflow |
| 风险/备注 | 自动化要做好权限、日志、重试和失败处理。 |
| 数据来源URL | https://zapier.com/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Make

> 可视化自动化平台。

| 字段 | 内容 |
|---|---|
| 原名 | Make |
| 直译 | 制作 |
| 常用中文名 | Make |
| 类别 | 14_自动化_Workflow_低代码 |
| 类型 | 平台/自动化 |
| 能给AI起到什么帮助 | 把AI能力接入业务流程、定时任务、API和多工具自动化。 |
| 代表平台/官网 | https://www.make.com/ |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 自动化,工作流,低代码,AgenticWorkflow |
| 风险/备注 | 自动化要做好权限、日志、重试和失败处理。 |
| 数据来源URL | https://www.make.com/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Pipedream

> 开发者自动化和API工作流平台。

| 字段 | 内容 |
|---|---|
| 原名 | Pipedream |
| 直译 | 管道梦 |
| 常用中文名 | Pipedream |
| 类别 | 14_自动化_Workflow_低代码 |
| 类型 | 平台/自动化 |
| 能给AI起到什么帮助 | 把AI能力接入业务流程、定时任务、API和多工具自动化。 |
| 代表平台/官网 | https://pipedream.com/ |
| 是否开源 | 部分 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 自动化,工作流,低代码,AgenticWorkflow |
| 风险/备注 | 自动化要做好权限、日志、重试和失败处理。 |
| 数据来源URL | https://pipedream.com/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Activepieces

> 开源自动化平台。

| 字段 | 内容 |
|---|---|
| 原名 | Activepieces |
| 直译 | 活动组件 |
| 常用中文名 | Activepieces |
| 类别 | 14_自动化_Workflow_低代码 |
| 类型 | 开源项目/自动化 |
| 能给AI起到什么帮助 | 把AI能力接入业务流程、定时任务、API和多工具自动化。 |
| 代表平台/官网 | https://github.com/activepieces/activepieces |
| 代表GitHub仓库 | activepieces/activepieces |
| GitHub Stars(约) | 18000 |
| Forks(约) | 2200 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 自动化,工作流,低代码,AgenticWorkflow |
| 风险/备注 | 自动化要做好权限、日志、重试和失败处理。 |
| 数据来源URL | https://github.com/activepieces/activepieces |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Node-RED

> 可视化流程编排工具。

| 字段 | 内容 |
|---|---|
| 原名 | Node-RED |
| 直译 | 节点红 |
| 常用中文名 | Node-RED |
| 类别 | 14_自动化_Workflow_低代码 |
| 类型 | 开源项目/自动化 |
| 能给AI起到什么帮助 | 把AI能力接入业务流程、定时任务、API和多工具自动化。 |
| 代表平台/官网 | https://github.com/node-red/node-red |
| 代表GitHub仓库 | node-red/node-red |
| GitHub Stars(约) | 20000 |
| Forks(约) | 3400 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 自动化,工作流,低代码,AgenticWorkflow |
| 风险/备注 | 自动化要做好权限、日志、重试和失败处理。 |
| 数据来源URL | https://github.com/node-red/node-red |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Temporal

> 持久工作流引擎，适合可靠长流程。

| 字段 | 内容 |
|---|---|
| 原名 | Temporal |
| 直译 | 时间性的 |
| 常用中文名 | Temporal |
| 类别 | 14_自动化_Workflow_低代码 |
| 类型 | 开源项目/工作流引擎 |
| 能给AI起到什么帮助 | 把AI能力接入业务流程、定时任务、API和多工具自动化。 |
| 代表平台/官网 | https://github.com/temporalio/temporal |
| 代表GitHub仓库 | temporalio/temporal |
| GitHub Stars(约) | 15000 |
| Forks(约) | 2000 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 自动化,工作流,低代码,AgenticWorkflow |
| 风险/备注 | 自动化要做好权限、日志、重试和失败处理。 |
| 数据来源URL | https://github.com/temporalio/temporal |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Airflow

> 数据任务调度和工作流编排。

| 字段 | 内容 |
|---|---|
| 原名 | Airflow |
| 直译 | 气流 |
| 常用中文名 | Apache Airflow |
| 类别 | 14_自动化_Workflow_低代码 |
| 类型 | 开源项目/数据工作流 |
| 能给AI起到什么帮助 | 把AI能力接入业务流程、定时任务、API和多工具自动化。 |
| 代表平台/官网 | https://github.com/apache/airflow |
| 代表GitHub仓库 | apache/airflow |
| GitHub Stars(约) | 40000 |
| Forks(约) | 14000 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 自动化,工作流,低代码,AgenticWorkflow |
| 风险/备注 | 自动化要做好权限、日志、重试和失败处理。 |
| 数据来源URL | https://github.com/apache/airflow |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Prefect

> 数据工作流编排平台。

| 字段 | 内容 |
|---|---|
| 原名 | Prefect |
| 直译 | 长官/完美者 |
| 常用中文名 | Prefect |
| 类别 | 14_自动化_Workflow_低代码 |
| 类型 | 开源项目/数据工作流 |
| 能给AI起到什么帮助 | 把AI能力接入业务流程、定时任务、API和多工具自动化。 |
| 代表平台/官网 | https://github.com/PrefectHQ/prefect |
| 代表GitHub仓库 | PrefectHQ/prefect |
| GitHub Stars(约) | 17000 |
| Forks(约) | 1700 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 自动化,工作流,低代码,AgenticWorkflow |
| 风险/备注 | 自动化要做好权限、日志、重试和失败处理。 |
| 数据来源URL | https://github.com/PrefectHQ/prefect |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：
