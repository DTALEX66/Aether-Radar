# 06_VibeCoding_AI编程

- 词条数量：42
- 更新时间：2026-06-21
- 用法：先看表格总览，再在下方词条内记录教程、试用经验、接入步骤。

## 快速总览

| 原名 | 直译 | 常用中文名 | 类型 | 热度 | Stars | Forks | 开源 | 本地部署 | 适合Codex | 来源 |
|---|---|---|---|---|---:|---:|---|---|---|---|
| Vibe Coding | 氛围编程/感觉编程 | Vibe Coding | 术语 |  |  |  |  |  |  |  |
| Agentic Coding | 智能体编程 | Agentic Coding | 术语 |  |  |  |  |  |  |  |
| AI Pair Programming | AI结对编程 | AI结对编程 | 术语 |  |  |  |  |  |  |  |
| Prompt-to-Code | 提示到代码 | 提示词生成代码 | 术语 |  |  |  |  |  |  |  |
| Prompt-to-App | 提示到应用 | 提示词生成应用 | 术语 |  |  |  |  |  |  |  |
| Spec-driven Development | 规格驱动开发 | 规格驱动开发 | 术语 |  |  |  |  |  |  |  |
| PRD | Product Requirements Document 直译：产品需求文档 | 产品需求文档 | 术语 |  |  |  |  |  |  |  |
| TRD | Technical Requirements Document 直译：技术需求文档 | 技术需求文档 | 术语 |  |  |  |  |  |  |  |
| Implementation Plan | 实施计划 | 实现计划 | 术语 |  |  |  |  |  |  |  |
| Acceptance Criteria | 验收标准 | 验收标准 | 术语 |  |  |  |  |  |  |  |
| Codebase Understanding | 代码库理解 | 代码库理解 | 术语 |  |  |  |  |  |  |  |
| Repo-aware Agent | 仓库感知智能体 | 仓库感知Agent | 术语 |  |  |  |  |  |  |  |
| Code Context | 代码上下文 | 代码上下文 | 术语 |  |  |  |  |  |  |  |
| Semantic Code Search | 语义代码搜索 | 语义代码搜索 | 术语 |  |  |  |  |  |  |  |
| Code Indexing | 代码索引 | 代码索引 | 术语 |  |  |  |  |  |  |  |
| AST | Abstract Syntax Tree 直译：抽象语法树 | 抽象语法树 | 术语 |  |  |  |  |  |  |  |
| LSP | Language Server Protocol 直译：语言服务器协议 | 语言服务器协议 | 术语 |  |  |  |  |  |  |  |
| Plan Mode | 计划模式 | 计划模式 | 术语 |  |  |  |  |  |  |  |
| Act Mode | 行动模式 | 执行模式 | 术语 |  |  |  |  |  |  |  |
| Diff | 差异 | 代码差异 | 术语 |  |  |  |  |  |  |  |
| Patch | 补丁 | 补丁 | 术语 |  |  |  |  |  |  |  |
| Commit | 提交 | Git提交 | 术语 |  |  |  |  |  |  |  |
| Pull Request | 拉取请求 | PR | 术语 |  |  |  |  |  |  |  |
| Code Review | 代码审查 | 代码审查 | 术语 |  |  |  |  |  |  |  |
| Unit Test | 单元测试 | 单元测试 | 术语 |  |  |  |  |  |  |  |
| Integration Test | 集成测试 | 集成测试 | 术语 |  |  |  |  |  |  |  |
| E2E Test | 端到端测试 | 端到端测试 | 术语 |  |  |  |  |  |  |  |
| Regression Test | 回归测试 | 回归测试 | 术语 |  |  |  |  |  |  |  |
| Static Analysis | 静态分析 | 静态分析 | 术语 |  |  |  |  |  |  |  |
| Lint | 棉絮/清理 | 代码规范检查 | 术语 |  |  |  |  |  |  |  |
| Type Check | 类型检查 | 类型检查 | 术语 |  |  |  |  |  |  |  |
| CI/CD | 持续集成/持续部署 | CI/CD | 术语 |  |  |  |  |  |  |  |
| Git Worktree | Git工作树 | Git工作树 | 术语 |  |  |  |  |  |  |  |
| Parallel Agents | 并行智能体 | 并行Agent | 术语 |  |  |  |  |  |  |  |
| Sandboxed Execution | 沙箱执行 | 沙箱执行 | 术语 |  |  |  |  |  |  |  |
| Dry Run | 干运行/试运行 | 试运行 | 术语 |  |  |  |  |  |  |  |
| Rollback Plan | 回滚计划 | 回滚方案 | 术语 |  |  |  |  |  |  |  |
| SWE-bench | 软件工程基准 | SWE-bench | 术语 |  |  |  |  |  |  |  |
| Silent Failure | 静默失败 | 静默失败 | 术语 |  |  |  |  |  |  |  |
| Scope Creep | 范围蔓延 | 范围膨胀 | 术语 |  |  |  |  |  |  |  |
| Over-engineering | 过度工程 | 过度工程化 | 术语 |  |  |  |  |  |  |  |
| Context Rot | 上下文腐烂 | 上下文腐烂 | 术语 |  |  |  |  |  |  |  |

## 详细词条

## Vibe Coding

> 人描述想要的效果，AI生成/修改/调试代码。

| 字段 | 内容 |
|---|---|
| 原名 | Vibe Coding |
| 直译 | 氛围编程/感觉编程 |
| 常用中文名 | Vibe Coding |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Agentic Coding

> AI自动读仓库、改代码、跑测试、提交PR。

| 字段 | 内容 |
|---|---|
| 原名 | Agentic Coding |
| 直译 | 智能体编程 |
| 常用中文名 | Agentic Coding |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## AI Pair Programming

> AI像搭档一样和人一起写代码。

| 字段 | 内容 |
|---|---|
| 原名 | AI Pair Programming |
| 直译 | AI结对编程 |
| 常用中文名 | AI结对编程 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Prompt-to-Code

> 用自然语言生成代码片段或模块。

| 字段 | 内容 |
|---|---|
| 原名 | Prompt-to-Code |
| 直译 | 提示到代码 |
| 常用中文名 | 提示词生成代码 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Prompt-to-App

> 用一句或一段需求生成完整应用。

| 字段 | 内容 |
|---|---|
| 原名 | Prompt-to-App |
| 直译 | 提示到应用 |
| 常用中文名 | 提示词生成应用 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Spec-driven Development

> 先写清需求和验收标准，再让AI开发。

| 字段 | 内容 |
|---|---|
| 原名 | Spec-driven Development |
| 直译 | 规格驱动开发 |
| 常用中文名 | 规格驱动开发 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## PRD

> 产品功能、用户流程、验收标准说明。

| 字段 | 内容 |
|---|---|
| 原名 | PRD |
| 直译 | Product Requirements Document 直译：产品需求文档 |
| 常用中文名 | 产品需求文档 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## TRD

> 技术架构、接口、数据结构、限制说明。

| 字段 | 内容 |
|---|---|
| 原名 | TRD |
| 直译 | Technical Requirements Document 直译：技术需求文档 |
| 常用中文名 | 技术需求文档 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Implementation Plan

> AI写代码前的分步方案。

| 字段 | 内容 |
|---|---|
| 原名 | Implementation Plan |
| 直译 | 实施计划 |
| 常用中文名 | 实现计划 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Acceptance Criteria

> 判断任务是否完成的明确条件。

| 字段 | 内容 |
|---|---|
| 原名 | Acceptance Criteria |
| 直译 | 验收标准 |
| 常用中文名 | 验收标准 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Codebase Understanding

> AI阅读项目结构、依赖和业务逻辑。

| 字段 | 内容 |
|---|---|
| 原名 | Codebase Understanding |
| 直译 | 代码库理解 |
| 常用中文名 | 代码库理解 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Repo-aware Agent

> 理解整个Git仓库，而不是只看当前文件。

| 字段 | 内容 |
|---|---|
| 原名 | Repo-aware Agent |
| 直译 | 仓库感知智能体 |
| 常用中文名 | 仓库感知Agent |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Code Context

> 让AI理解相关文件、依赖、规则。

| 字段 | 内容 |
|---|---|
| 原名 | Code Context |
| 直译 | 代码上下文 |
| 常用中文名 | 代码上下文 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Semantic Code Search

> 按意图查找代码，而非只靠关键词。

| 字段 | 内容 |
|---|---|
| 原名 | Semantic Code Search |
| 直译 | 语义代码搜索 |
| 常用中文名 | 语义代码搜索 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Code Indexing

> 为项目代码建立索引以便AI检索。

| 字段 | 内容 |
|---|---|
| 原名 | Code Indexing |
| 直译 | 代码索引 |
| 常用中文名 | 代码索引 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## AST

> 代码结构化表示，适合静态分析和重构。

| 字段 | 内容 |
|---|---|
| 原名 | AST |
| 直译 | Abstract Syntax Tree 直译：抽象语法树 |
| 常用中文名 | 抽象语法树 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## LSP

> 为编辑器提供跳转、补全、诊断能力。

| 字段 | 内容 |
|---|---|
| 原名 | LSP |
| 直译 | Language Server Protocol 直译：语言服务器协议 |
| 常用中文名 | 语言服务器协议 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Plan Mode

> 先调研和规划，不立即改文件。

| 字段 | 内容 |
|---|---|
| 原名 | Plan Mode |
| 直译 | 计划模式 |
| 常用中文名 | 计划模式 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Act Mode

> 允许AI改文件、跑命令、调用工具。

| 字段 | 内容 |
|---|---|
| 原名 | Act Mode |
| 直译 | 行动模式 |
| 常用中文名 | 执行模式 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Diff

> 文件改动前后对比。

| 字段 | 内容 |
|---|---|
| 原名 | Diff |
| 直译 | 差异 |
| 常用中文名 | 代码差异 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Patch

> 可应用到项目的一组代码修改。

| 字段 | 内容 |
|---|---|
| 原名 | Patch |
| 直译 | 补丁 |
| 常用中文名 | 补丁 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Commit

> 一次Git代码变更记录。

| 字段 | 内容 |
|---|---|
| 原名 | Commit |
| 直译 | 提交 |
| 常用中文名 | Git提交 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Pull Request

> 提交代码变更给项目审查。

| 字段 | 内容 |
|---|---|
| 原名 | Pull Request |
| 直译 | 拉取请求 |
| 常用中文名 | PR |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Code Review

> 检查代码质量、安全、性能和规范。

| 字段 | 内容 |
|---|---|
| 原名 | Code Review |
| 直译 | 代码审查 |
| 常用中文名 | 代码审查 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Unit Test

> 测试最小功能单元。

| 字段 | 内容 |
|---|---|
| 原名 | Unit Test |
| 直译 | 单元测试 |
| 常用中文名 | 单元测试 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Integration Test

> 测试多个模块协作。

| 字段 | 内容 |
|---|---|
| 原名 | Integration Test |
| 直译 | 集成测试 |
| 常用中文名 | 集成测试 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## E2E Test

> 模拟真实用户流程。

| 字段 | 内容 |
|---|---|
| 原名 | E2E Test |
| 直译 | 端到端测试 |
| 常用中文名 | 端到端测试 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Regression Test

> 确认新改动没有破坏旧功能。

| 字段 | 内容 |
|---|---|
| 原名 | Regression Test |
| 直译 | 回归测试 |
| 常用中文名 | 回归测试 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Static Analysis

> 不运行代码也能发现问题。

| 字段 | 内容 |
|---|---|
| 原名 | Static Analysis |
| 直译 | 静态分析 |
| 常用中文名 | 静态分析 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Lint

> 检查格式、风格和潜在错误。

| 字段 | 内容 |
|---|---|
| 原名 | Lint |
| 直译 | 棉絮/清理 |
| 常用中文名 | 代码规范检查 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Type Check

> 检查类型错误。

| 字段 | 内容 |
|---|---|
| 原名 | Type Check |
| 直译 | 类型检查 |
| 常用中文名 | 类型检查 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## CI/CD

> 自动测试、构建、部署。

| 字段 | 内容 |
|---|---|
| 原名 | CI/CD |
| 直译 | 持续集成/持续部署 |
| 常用中文名 | CI/CD |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Git Worktree

> 同一仓库开多个工作区，适合多Agent并行。

| 字段 | 内容 |
|---|---|
| 原名 | Git Worktree |
| 直译 | Git工作树 |
| 常用中文名 | Git工作树 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Parallel Agents

> 多个Agent同时做不同分支或任务。

| 字段 | 内容 |
|---|---|
| 原名 | Parallel Agents |
| 直译 | 并行智能体 |
| 常用中文名 | 并行Agent |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Sandboxed Execution

> 隔离运行AI命令，降低破坏风险。

| 字段 | 内容 |
|---|---|
| 原名 | Sandboxed Execution |
| 直译 | 沙箱执行 |
| 常用中文名 | 沙箱执行 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Dry Run

> 模拟执行，不真正修改或提交。

| 字段 | 内容 |
|---|---|
| 原名 | Dry Run |
| 直译 | 干运行/试运行 |
| 常用中文名 | 试运行 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Rollback Plan

> AI改坏后恢复。

| 字段 | 内容 |
|---|---|
| 原名 | Rollback Plan |
| 直译 | 回滚计划 |
| 常用中文名 | 回滚方案 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## SWE-bench

> 评测AI解决真实GitHub issue的代码benchmark。

| 字段 | 内容 |
|---|---|
| 原名 | SWE-bench |
| 直译 | 软件工程基准 |
| 常用中文名 | SWE-bench |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Silent Failure

> 看起来完成但隐藏bug。

| 字段 | 内容 |
|---|---|
| 原名 | Silent Failure |
| 直译 | 静默失败 |
| 常用中文名 | 静默失败 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Scope Creep

> AI越改越多，超出原需求。

| 字段 | 内容 |
|---|---|
| 原名 | Scope Creep |
| 直译 | 范围蔓延 |
| 常用中文名 | 范围膨胀 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Over-engineering

> 简单需求被AI做复杂。

| 字段 | 内容 |
|---|---|
| 原名 | Over-engineering |
| 直译 | 过度工程 |
| 常用中文名 | 过度工程化 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Context Rot

> 上下文过长/过乱导致模型混乱。

| 字段 | 内容 |
|---|---|
| 原名 | Context Rot |
| 直译 | 上下文腐烂 |
| 常用中文名 | 上下文腐烂 |
| 类别 | 06_VibeCoding_AI编程 |
| 类型 | 术语 |
| 能给AI起到什么帮助 | 提高用Codex/Claude/Cursor开发项目的成功率。 |
| 适合商业项目 | 是 |
| 关键词标签 | AI编程,VibeCoding,Codex,Cursor,ClaudeCode |
| 数据状态 | 术语/无需热度 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：
