# 13_Obsidian_第二大脑_个人知识库

- 词条数量：13
- 更新时间：2026-06-21
- 用法：先看表格总览，再在下方词条内记录教程、试用经验、接入步骤。

## 快速总览

| 原名 | 直译 | 常用中文名 | 类型 | 热度 | Stars | Forks | 开源 | 本地部署 | 适合Codex | 来源 |
|---|---|---|---|---|---:|---:|---|---|---|---|
| Obsidian | 黑曜石 | Obsidian | 软件/知识管理 | 高热 |  |  | 否 | 是 | 是 | https://obsidian.md/ |
| NotebookLM | 笔记本语言模型 | NotebookLM | 平台/资料AI | 国际高热 |  |  | 否 | 否 | 否 | https://notebooklm.google/ |
| Notion AI | 概念AI | Notion AI | 平台/知识库 | 国际顶流 |  |  | 否 | 否 | 部分 | https://www.notion.com/product/ai |
| Logseq | 日志序列 | Logseq | 开源项目/知识管理 | S 高热 | 34000 | 1900 | 是 | 是 | 是 | https://github.com/logseq/logseq |
| Roam Research | 漫游研究 | Roam Research | 平台/知识管理 | 国际中高热 |  |  | 否 | 否 | 否 | https://roamresearch.com/ |
| Tana | 品牌名 | Tana | 平台/知识管理 | 国际中高热 |  |  | 否 | 否 | 部分 | https://tana.inc/ |
| Heptabase | 七基底 | Heptabase | 平台/知识管理 | 国际中高热 |  |  | 否 | 否 | 部分 | https://heptabase.com/ |
| Readwise | 阅读智慧 | Readwise | 平台/阅读管理 | 国际高热 |  |  | 否 | 否 | 部分 | https://readwise.io/ |
| Zotero | 品牌名 | Zotero | 开源项目/文献管理 | A 中高热 | 11000 | 800 | 是 | 是 | 部分 | https://github.com/zotero/zotero |
| Pieces | 碎片 | Pieces | 软件/开发者记忆 | 国际中高热 |  |  | 否 | 是 | 是 | https://pieces.app/ |
| Anytype | 任意类型 | Anytype | 开源项目/知识管理 | B 垂直热 | 6000 | 500 | 是 | 是 | 部分 | https://github.com/anyproto/anytype-ts |
| Raindrop.io | 雨滴 | Raindrop.io | 平台/书签管理 | 国际中高热 |  |  | 否 | 否 | 部分 | https://raindrop.io/ |
| Omnivore | 杂食者 | Omnivore | 开源项目/阅读管理 | A 中高热 | 14000 | 900 | 是 | 部分 | 部分 | https://github.com/omnivore-app/omnivore |

## 详细词条

## Obsidian

> 本地Markdown知识库，适合做AI长期记忆和RAG数据源。

| 字段 | 内容 |
|---|---|
| 原名 | Obsidian |
| 直译 | 黑曜石 |
| 常用中文名 | Obsidian |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 软件/知识管理 |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://obsidian.md/ |
| 热度等级 | 高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 本地文件结构清晰，适合长期积累。 |
| 数据来源URL | https://obsidian.md/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## NotebookLM

> Google资料型AI笔记工具，基于上传资料问答和总结。

| 字段 | 内容 |
|---|---|
| 原名 | NotebookLM |
| 直译 | 笔记本语言模型 |
| 常用中文名 | NotebookLM |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 平台/资料AI |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://notebooklm.google/ |
| 热度等级 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 否 |
| 适合Claude Code | 否 |
| 适合Cursor | 否 |
| 适合商业项目 | 是 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 适合研究资料，平台闭源。 |
| 数据来源URL | https://notebooklm.google/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Notion AI

> 在线文档/数据库/知识库中的AI能力。

| 字段 | 内容 |
|---|---|
| 原名 | Notion AI |
| 直译 | 概念AI |
| 常用中文名 | Notion AI |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 平台/知识库 |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://www.notion.com/product/ai |
| 热度等级 | 国际顶流 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 在线平台，数据权限需管理。 |
| 数据来源URL | https://www.notion.com/product/ai |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Logseq

> 本地优先双链笔记。

| 字段 | 内容 |
|---|---|
| 原名 | Logseq |
| 直译 | 日志序列 |
| 常用中文名 | Logseq |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 开源项目/知识管理 |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://github.com/logseq/logseq |
| 代表GitHub仓库 | logseq/logseq |
| GitHub Stars(约) | 34000 |
| Forks(约) | 1900 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 部分 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 插件生态需要维护。 |
| 数据来源URL | https://github.com/logseq/logseq |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Roam Research

> 双链笔记工具代表。

| 字段 | 内容 |
|---|---|
| 原名 | Roam Research |
| 直译 | 漫游研究 |
| 常用中文名 | Roam Research |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 平台/知识管理 |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://roamresearch.com/ |
| 热度等级 | 国际中高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 否 |
| 适合Claude Code | 否 |
| 适合Cursor | 否 |
| 适合商业项目 | 部分 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 付费平台。 |
| 数据来源URL | https://roamresearch.com/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Tana

> 结构化笔记/知识管理/AI工作流工具。

| 字段 | 内容 |
|---|---|
| 原名 | Tana |
| 直译 | 品牌名 |
| 常用中文名 | Tana |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 平台/知识管理 |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://tana.inc/ |
| 热度等级 | 国际中高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 部分 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 学习曲线较高。 |
| 数据来源URL | https://tana.inc/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Heptabase

> 卡片式白板知识管理。

| 字段 | 内容 |
|---|---|
| 原名 | Heptabase |
| 直译 | 七基底 |
| 常用中文名 | Heptabase |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 平台/知识管理 |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://heptabase.com/ |
| 热度等级 | 国际中高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 部分 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 适合研究型用户。 |
| 数据来源URL | https://heptabase.com/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Readwise

> 阅读标注同步工具。

| 字段 | 内容 |
|---|---|
| 原名 | Readwise |
| 直译 | 阅读智慧 |
| 常用中文名 | Readwise |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 平台/阅读管理 |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://readwise.io/ |
| 热度等级 | 国际高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 部分 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 适合构建阅读知识库。 |
| 数据来源URL | https://readwise.io/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Zotero

> 文献管理工具，可作为论文资料库。

| 字段 | 内容 |
|---|---|
| 原名 | Zotero |
| 直译 | 品牌名 |
| 常用中文名 | Zotero |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 开源项目/文献管理 |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://github.com/zotero/zotero |
| 代表GitHub仓库 | zotero/zotero |
| GitHub Stars(约) | 11000 |
| Forks(约) | 800 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 科研/论文场景强。 |
| 数据来源URL | https://github.com/zotero/zotero |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Pieces

> 开发者本地优先AI工作流记忆工具。

| 字段 | 内容 |
|---|---|
| 原名 | Pieces |
| 直译 | 碎片 |
| 常用中文名 | Pieces |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 软件/开发者记忆 |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://pieces.app/ |
| 热度等级 | 国际中高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 部分 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 适合代码片段和工作流记忆。 |
| 数据来源URL | https://pieces.app/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Anytype

> 本地优先对象化知识库。

| 字段 | 内容 |
|---|---|
| 原名 | Anytype |
| 直译 | 任意类型 |
| 常用中文名 | Anytype |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 开源项目/知识管理 |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://github.com/anyproto/anytype-ts |
| 代表GitHub仓库 | anyproto/anytype-ts |
| GitHub Stars(约) | 6000 |
| Forks(约) | 500 |
| 热度等级 | B 垂直热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 部分 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 生态仍发展中。 |
| 数据来源URL | https://github.com/anyproto/anytype-ts |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Raindrop.io

> 书签管理工具，可做AI资料入口。

| 字段 | 内容 |
|---|---|
| 原名 | Raindrop.io |
| 直译 | 雨滴 |
| 常用中文名 | Raindrop.io |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 平台/书签管理 |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://raindrop.io/ |
| 热度等级 | 国际中高热 |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 是 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 适合收集资料。 |
| 数据来源URL | https://raindrop.io/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Omnivore

> 开源稍后读/阅读器。

| 字段 | 内容 |
|---|---|
| 原名 | Omnivore |
| 直译 | 杂食者 |
| 常用中文名 | Omnivore |
| 类别 | 13_Obsidian_第二大脑_个人知识库 |
| 类型 | 开源项目/阅读管理 |
| 能给AI起到什么帮助 | 作为AI长期记忆、项目知识库、RAG数据源、资料中控台。 |
| 代表平台/官网 | https://github.com/omnivore-app/omnivore |
| 代表GitHub仓库 | omnivore-app/omnivore |
| GitHub Stars(约) | 14000 |
| Forks(约) | 900 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 部分 |
| 适合Claude Code | 部分 |
| 适合Cursor | 部分 |
| 适合商业项目 | 部分 |
| 关键词标签 | 知识库,第二大脑,Obsidian,RAG,AI记忆 |
| 风险/备注 | 需关注服务/维护状态。 |
| 数据来源URL | https://github.com/omnivore-app/omnivore |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：
