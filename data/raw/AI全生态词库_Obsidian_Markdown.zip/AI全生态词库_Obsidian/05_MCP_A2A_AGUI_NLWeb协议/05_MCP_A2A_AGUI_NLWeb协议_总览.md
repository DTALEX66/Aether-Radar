# 05_MCP_A2A_AGUI_NLWeb协议

- 词条数量：18
- 更新时间：2026-06-21
- 用法：先看表格总览，再在下方词条内记录教程、试用经验、接入步骤。

## 快速总览

| 原名 | 直译 | 常用中文名 | 类型 | 热度 | Stars | Forks | 开源 | 本地部署 | 适合Codex | 来源 |
|---|---|---|---|---|---:|---:|---|---|---|---|
| MCP | Model Context Protocol 直译：模型上下文协议 | 模型上下文协议 | 协议/术语 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| MCP Host | MCP主机 | MCP主机 | 协议/术语 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| MCP Client | MCP客户端 | MCP客户端 | 协议/术语 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| MCP Server | MCP服务端 | MCP服务端 | 协议/术语 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| MCP Tool | MCP工具 | MCP工具 | 协议/术语 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| MCP Resource | MCP资源 | MCP资源 | 协议/术语 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| MCP Prompt | MCP提示 | MCP提示模板 | 协议/术语 |  |  |  |  |  |  | https://modelcontextprotocol.io/ |
| FastMCP | 快速MCP | FastMCP | 协议/术语 |  |  |  |  |  |  | https://github.com/modelcontextprotocol/python-sdk |
| A2A | Agent to Agent 直译：智能体到智能体 | Agent2Agent协议 | 协议/术语 |  |  |  |  |  |  | https://developers.googleblog.com/ |
| Agent Card | 智能体卡片 | Agent Card | 协议/术语 |  |  |  |  |  |  | https://developers.googleblog.com/ |
| AG-UI | Agent-User Interaction 直译：智能体-用户交互 | AG-UI协议 | 协议/术语 |  |  |  |  |  |  | https://docs.ag-ui.com/ |
| NLWeb | Natural Language Web 直译：自然语言网页 | NLWeb | 协议/术语 |  |  |  |  |  |  | https://github.com/nlweb-ai/NLWeb |
| AP2 | Agent Payments Protocol 直译：智能体支付协议 | Agent支付协议 | 协议/术语 |  |  |  |  |  |  |  |
| Tool Registry | 工具注册表 | 工具注册表 | 协议/术语 |  |  |  |  |  |  |  |
| Tool Schema | 工具结构 | 工具Schema | 协议/术语 |  |  |  |  |  |  |  |
| Tool Poisoning | 工具投毒 | 工具投毒 | 协议/术语 |  |  |  |  |  |  |  |
| Connector Protocol | 连接器协议 | 连接器协议 | 协议/术语 |  |  |  |  |  |  |  |
| Protocol Adapter | 协议适配器 | 协议适配器 | 协议/术语 |  |  |  |  |  |  |  |

## 详细词条

## MCP

> 连接AI应用与外部工具/数据源的开放协议。

| 字段 | 内容 |
|---|---|
| 原名 | MCP |
| 直译 | Model Context Protocol 直译：模型上下文协议 |
| 常用中文名 | 模型上下文协议 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 代表平台/官网 | https://modelcontextprotocol.io/ |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据来源URL | https://modelcontextprotocol.io/ |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## MCP Host

> 承载AI和MCP客户端的应用。

| 字段 | 内容 |
|---|---|
| 原名 | MCP Host |
| 直译 | MCP主机 |
| 常用中文名 | MCP主机 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 代表平台/官网 | https://modelcontextprotocol.io/ |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据来源URL | https://modelcontextprotocol.io/ |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## MCP Client

> 负责和MCP Server通信的组件。

| 字段 | 内容 |
|---|---|
| 原名 | MCP Client |
| 直译 | MCP客户端 |
| 常用中文名 | MCP客户端 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 代表平台/官网 | https://modelcontextprotocol.io/ |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据来源URL | https://modelcontextprotocol.io/ |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## MCP Server

> 对外提供工具、资源、提示模板的服务。

| 字段 | 内容 |
|---|---|
| 原名 | MCP Server |
| 直译 | MCP服务端 |
| 常用中文名 | MCP服务端 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 代表平台/官网 | https://modelcontextprotocol.io/ |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据来源URL | https://modelcontextprotocol.io/ |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## MCP Tool

> AI可以通过MCP调用的具体能力。

| 字段 | 内容 |
|---|---|
| 原名 | MCP Tool |
| 直译 | MCP工具 |
| 常用中文名 | MCP工具 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 代表平台/官网 | https://modelcontextprotocol.io/ |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据来源URL | https://modelcontextprotocol.io/ |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## MCP Resource

> AI可以通过MCP读取的数据或文件。

| 字段 | 内容 |
|---|---|
| 原名 | MCP Resource |
| 直译 | MCP资源 |
| 常用中文名 | MCP资源 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 代表平台/官网 | https://modelcontextprotocol.io/ |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据来源URL | https://modelcontextprotocol.io/ |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## MCP Prompt

> MCP Server提供的标准提示模板。

| 字段 | 内容 |
|---|---|
| 原名 | MCP Prompt |
| 直译 | MCP提示 |
| 常用中文名 | MCP提示模板 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 代表平台/官网 | https://modelcontextprotocol.io/ |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据来源URL | https://modelcontextprotocol.io/ |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## FastMCP

> 快速构建MCP Server的工具/框架。

| 字段 | 内容 |
|---|---|
| 原名 | FastMCP |
| 直译 | 快速MCP |
| 常用中文名 | FastMCP |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 代表平台/官网 | https://github.com/modelcontextprotocol/python-sdk |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据来源URL | https://github.com/modelcontextprotocol/python-sdk |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## A2A

> Agent之间互相发现、通信、协作的协议方向。

| 字段 | 内容 |
|---|---|
| 原名 | A2A |
| 直译 | Agent to Agent 直译：智能体到智能体 |
| 常用中文名 | Agent2Agent协议 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 代表平台/官网 | https://developers.googleblog.com/ |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据来源URL | https://developers.googleblog.com/ |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Agent Card

> 描述Agent能力、端点、认证方式的公开说明。

| 字段 | 内容 |
|---|---|
| 原名 | Agent Card |
| 直译 | 智能体卡片 |
| 常用中文名 | Agent Card |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 代表平台/官网 | https://developers.googleblog.com/ |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据来源URL | https://developers.googleblog.com/ |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## AG-UI

> 连接Agent后端和前端UI的事件式协议。

| 字段 | 内容 |
|---|---|
| 原名 | AG-UI |
| 直译 | Agent-User Interaction 直译：智能体-用户交互 |
| 常用中文名 | AG-UI协议 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 代表平台/官网 | https://docs.ag-ui.com/ |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据来源URL | https://docs.ag-ui.com/ |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## NLWeb

> 让网站提供自然语言接口和Agent可访问入口。

| 字段 | 内容 |
|---|---|
| 原名 | NLWeb |
| 直译 | Natural Language Web 直译：自然语言网页 |
| 常用中文名 | NLWeb |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 代表平台/官网 | https://github.com/nlweb-ai/NLWeb |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据来源URL | https://github.com/nlweb-ai/NLWeb |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## AP2

> 面向Agent代用户付款/下单的支付协议方向。

| 字段 | 内容 |
|---|---|
| 原名 | AP2 |
| 直译 | Agent Payments Protocol 直译：智能体支付协议 |
| 常用中文名 | Agent支付协议 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Tool Registry

> Agent可用工具的清单和目录。

| 字段 | 内容 |
|---|---|
| 原名 | Tool Registry |
| 直译 | 工具注册表 |
| 常用中文名 | 工具注册表 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Tool Schema

> 定义工具名称、参数、返回值。

| 字段 | 内容 |
|---|---|
| 原名 | Tool Schema |
| 直译 | 工具结构 |
| 常用中文名 | 工具Schema |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Tool Poisoning

> 恶意工具说明诱导Agent错误执行。

| 字段 | 内容 |
|---|---|
| 原名 | Tool Poisoning |
| 直译 | 工具投毒 |
| 常用中文名 | 工具投毒 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Connector Protocol

> 统一连接外部应用和服务的协议。

| 字段 | 内容 |
|---|---|
| 原名 | Connector Protocol |
| 直译 | 连接器协议 |
| 常用中文名 | 连接器协议 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Protocol Adapter

> 在不同协议之间做转换。

| 字段 | 内容 |
|---|---|
| 原名 | Protocol Adapter |
| 直译 | 协议适配器 |
| 常用中文名 | 协议适配器 |
| 类别 | 05_MCP_A2A_AGUI_NLWeb协议 |
| 类型 | 协议/术语 |
| 能给AI起到什么帮助 | 让AI连接工具、Agent、网页和UI。 |
| 适合商业项目 | 是 |
| 关键词标签 | 协议,MCP,A2A,Agent连接 |
| 数据状态 | 术语/平台公开 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：
