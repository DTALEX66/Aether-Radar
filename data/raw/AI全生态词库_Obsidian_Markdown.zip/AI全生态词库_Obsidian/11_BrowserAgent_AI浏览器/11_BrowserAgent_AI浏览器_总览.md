# 11_BrowserAgent_AI浏览器

- 词条数量：10
- 更新时间：2026-06-21
- 用法：先看表格总览，再在下方词条内记录教程、试用经验、接入步骤。

## 快速总览

| 原名 | 直译 | 常用中文名 | 类型 | 热度 | Stars | Forks | 开源 | 本地部署 | 适合Codex | 来源 |
|---|---|---|---|---|---:|---:|---|---|---|---|
| Browser-use | 浏览器使用 | Browser-use | 开源项目/浏览器Agent | SS 顶流 | 99800 | 11100 | 是 | 部分 | 是 | https://github.com/browser-use/browser-use |
| Stagehand | 舞台助手 | Stagehand | 开源项目/浏览器自动化 | S 高热 | 23200 | 1600 | 是 | 部分 | 是 | https://github.com/browserbase/stagehand |
| Playwright | 剧作家 | Playwright | 开源项目/浏览器自动化 | SS 顶流 | 75000 | 4300 | 是 | 是 | 是 | https://github.com/microsoft/playwright |
| Selenium | 硒 | Selenium | 开源项目/浏览器自动化 | S 高热 | 33000 | 8000 | 是 | 是 | 是 | https://github.com/SeleniumHQ/selenium |
| Puppeteer | 操偶师 | Puppeteer | 开源项目/浏览器自动化 | SS 顶流 | 92000 | 9000 | 是 | 是 | 是 | https://github.com/puppeteer/puppeteer |
| Browserbase | 浏览器基地 | Browserbase | 平台/浏览器基础设施 |  |  |  | 否 | 否 | 是 | https://www.browserbase.com/ |
| Comet | 彗星 | Perplexity Comet | 平台/AI浏览器 |  |  |  | 否 | 否 | 否 | https://www.perplexity.ai/comet |
| Dia | 品牌名 | Dia Browser | 平台/AI浏览器 |  |  |  | 否 | 否 | 否 | https://www.diabrowser.com/ |
| Operator | 操作者 | OpenAI Operator | 平台/网页Agent |  |  |  | 否 | 否 | 否 | https://openai.com/index/introducing-operator/ |
| Computer Use | 电脑使用 | Computer Use | 术语/能力 |  |  |  |  |  | 是 |  |

## 详细词条

## Browser-use

> 让AI Agent操作真实网站和浏览器任务。

| 字段 | 内容 |
|---|---|
| 原名 | Browser-use |
| 直译 | 浏览器使用 |
| 常用中文名 | Browser-use |
| 类别 | 11_BrowserAgent_AI浏览器 |
| 类型 | 开源项目/浏览器Agent |
| 能给AI起到什么帮助 | 让AI操作网页、填表、抓取信息和执行网页任务。 |
| 代表平台/官网 | https://github.com/browser-use/browser-use |
| 代表GitHub仓库 | browser-use/browser-use |
| GitHub Stars(约) | 99800 |
| Forks(约) | 11100 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | BrowserAgent,网页自动化,AI浏览器 |
| 风险/备注 | AI浏览器有提示注入、误操作、账号权限风险。 |
| 数据来源URL | https://github.com/browser-use/browser-use |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Stagehand

> Browserbase出品，用自然语言+代码控制浏览器。

| 字段 | 内容 |
|---|---|
| 原名 | Stagehand |
| 直译 | 舞台助手 |
| 常用中文名 | Stagehand |
| 类别 | 11_BrowserAgent_AI浏览器 |
| 类型 | 开源项目/浏览器自动化 |
| 能给AI起到什么帮助 | 让AI操作网页、填表、抓取信息和执行网页任务。 |
| 代表平台/官网 | https://github.com/browserbase/stagehand |
| 代表GitHub仓库 | browserbase/stagehand |
| GitHub Stars(约) | 23200 |
| Forks(约) | 1600 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 部分 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | BrowserAgent,网页自动化,AI浏览器 |
| 风险/备注 | AI浏览器有提示注入、误操作、账号权限风险。 |
| 数据来源URL | https://github.com/browserbase/stagehand |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Playwright

> 微软浏览器自动化和E2E测试库。

| 字段 | 内容 |
|---|---|
| 原名 | Playwright |
| 直译 | 剧作家 |
| 常用中文名 | Playwright |
| 类别 | 11_BrowserAgent_AI浏览器 |
| 类型 | 开源项目/浏览器自动化 |
| 能给AI起到什么帮助 | 让AI操作网页、填表、抓取信息和执行网页任务。 |
| 代表平台/官网 | https://github.com/microsoft/playwright |
| 代表GitHub仓库 | microsoft/playwright |
| GitHub Stars(约) | 75000 |
| Forks(约) | 4300 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | BrowserAgent,网页自动化,AI浏览器 |
| 风险/备注 | AI浏览器有提示注入、误操作、账号权限风险。 |
| 数据来源URL | https://github.com/microsoft/playwright |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Selenium

> 老牌浏览器自动化框架。

| 字段 | 内容 |
|---|---|
| 原名 | Selenium |
| 直译 | 硒 |
| 常用中文名 | Selenium |
| 类别 | 11_BrowserAgent_AI浏览器 |
| 类型 | 开源项目/浏览器自动化 |
| 能给AI起到什么帮助 | 让AI操作网页、填表、抓取信息和执行网页任务。 |
| 代表平台/官网 | https://github.com/SeleniumHQ/selenium |
| 代表GitHub仓库 | SeleniumHQ/selenium |
| GitHub Stars(约) | 33000 |
| Forks(约) | 8000 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | BrowserAgent,网页自动化,AI浏览器 |
| 风险/备注 | AI浏览器有提示注入、误操作、账号权限风险。 |
| 数据来源URL | https://github.com/SeleniumHQ/selenium |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Puppeteer

> Node.js控制Chrome/Chromium的自动化库。

| 字段 | 内容 |
|---|---|
| 原名 | Puppeteer |
| 直译 | 操偶师 |
| 常用中文名 | Puppeteer |
| 类别 | 11_BrowserAgent_AI浏览器 |
| 类型 | 开源项目/浏览器自动化 |
| 能给AI起到什么帮助 | 让AI操作网页、填表、抓取信息和执行网页任务。 |
| 代表平台/官网 | https://github.com/puppeteer/puppeteer |
| 代表GitHub仓库 | puppeteer/puppeteer |
| GitHub Stars(约) | 92000 |
| Forks(约) | 9000 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | BrowserAgent,网页自动化,AI浏览器 |
| 风险/备注 | AI浏览器有提示注入、误操作、账号权限风险。 |
| 数据来源URL | https://github.com/puppeteer/puppeteer |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Browserbase

> 为浏览器Agent提供云端浏览器基础设施。

| 字段 | 内容 |
|---|---|
| 原名 | Browserbase |
| 直译 | 浏览器基地 |
| 常用中文名 | Browserbase |
| 类别 | 11_BrowserAgent_AI浏览器 |
| 类型 | 平台/浏览器基础设施 |
| 能给AI起到什么帮助 | 让AI操作网页、填表、抓取信息和执行网页任务。 |
| 代表平台/官网 | https://www.browserbase.com/ |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | BrowserAgent,网页自动化,AI浏览器 |
| 风险/备注 | AI浏览器有提示注入、误操作、账号权限风险。 |
| 数据来源URL | https://www.browserbase.com/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Comet

> Perplexity AI浏览器。

| 字段 | 内容 |
|---|---|
| 原名 | Comet |
| 直译 | 彗星 |
| 常用中文名 | Perplexity Comet |
| 类别 | 11_BrowserAgent_AI浏览器 |
| 类型 | 平台/AI浏览器 |
| 能给AI起到什么帮助 | 让AI操作网页、填表、抓取信息和执行网页任务。 |
| 代表平台/官网 | https://www.perplexity.ai/comet |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 否 |
| 适合Claude Code | 否 |
| 适合Cursor | 否 |
| 适合商业项目 | 部分 |
| 关键词标签 | BrowserAgent,网页自动化,AI浏览器 |
| 风险/备注 | AI浏览器有提示注入、误操作、账号权限风险。 |
| 数据来源URL | https://www.perplexity.ai/comet |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Dia

> The Browser Company的AI浏览器方向产品。

| 字段 | 内容 |
|---|---|
| 原名 | Dia |
| 直译 | 品牌名 |
| 常用中文名 | Dia Browser |
| 类别 | 11_BrowserAgent_AI浏览器 |
| 类型 | 平台/AI浏览器 |
| 能给AI起到什么帮助 | 让AI操作网页、填表、抓取信息和执行网页任务。 |
| 代表平台/官网 | https://www.diabrowser.com/ |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 否 |
| 适合Claude Code | 否 |
| 适合Cursor | 否 |
| 适合商业项目 | 部分 |
| 关键词标签 | BrowserAgent,网页自动化,AI浏览器 |
| 风险/备注 | AI浏览器有提示注入、误操作、账号权限风险。 |
| 数据来源URL | https://www.diabrowser.com/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Operator

> OpenAI网页任务执行Agent方向产品。

| 字段 | 内容 |
|---|---|
| 原名 | Operator |
| 直译 | 操作者 |
| 常用中文名 | OpenAI Operator |
| 类别 | 11_BrowserAgent_AI浏览器 |
| 类型 | 平台/网页Agent |
| 能给AI起到什么帮助 | 让AI操作网页、填表、抓取信息和执行网页任务。 |
| 代表平台/官网 | https://openai.com/index/introducing-operator/ |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 否 |
| 适合Claude Code | 否 |
| 适合Cursor | 否 |
| 适合商业项目 | 部分 |
| 关键词标签 | BrowserAgent,网页自动化,AI浏览器 |
| 风险/备注 | AI浏览器有提示注入、误操作、账号权限风险。 |
| 数据来源URL | https://openai.com/index/introducing-operator/ |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Computer Use

> AI看屏幕、点按钮、输入文字的能力。

| 字段 | 内容 |
|---|---|
| 原名 | Computer Use |
| 直译 | 电脑使用 |
| 常用中文名 | Computer Use |
| 类别 | 11_BrowserAgent_AI浏览器 |
| 类型 | 术语/能力 |
| 能给AI起到什么帮助 | 让AI操作网页、填表、抓取信息和执行网页任务。 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | BrowserAgent,网页自动化,AI浏览器 |
| 风险/备注 | AI浏览器有提示注入、误操作、账号权限风险。 |
| 数据状态 | GitHub采集/平台公开/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：
