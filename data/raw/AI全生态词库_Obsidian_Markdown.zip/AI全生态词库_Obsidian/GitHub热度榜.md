# GitHub热度榜

- 项目数量：87
- 更新时间：2026-06-21

| 排名 | 原名 | 常用中文名 | 类别 | Stars(约) | Forks(约) | 热度等级 | GitHub |
|---:|---|---|---|---:|---:|---|---|
| 1 | opencode | opencode | 07_AI编程工具_IDE_Agent | 177000 | 21600 | SSS 超顶流 | sst/opencode |
| 2 | Ollama | Ollama | 09_本地模型_部署_推理 | 175000 | 16700 | SSS 超顶流 | ollama/ollama |
| 3 | Hugging Face Transformers | Transformers | 09_本地模型_部署_推理 | 162000 | 33600 | SSS 超顶流 | huggingface/transformers |
| 4 | Langflow | Langflow | 08_Agent框架_RAG框架_开发库 | 150000 | 9300 | SSS 超顶流 | langflow-ai/langflow |
| 5 | AUTOMATIC1111 | Stable Diffusion WebUI | 12_设计_图像_视频AI | 150000 | 28000 | SSS 超顶流 | AUTOMATIC1111/stable-diffusion-webui |
| 6 | Langflow | Langflow | 14_自动化_Workflow_低代码 | 150000 | 9300 | SSS 超顶流 | langflow-ai/langflow |
| 7 | Dify | Dify | 08_Agent框架_RAG框架_开发库 | 145982 | 22959 | SSS 超顶流 | langgenius/dify |
| 8 | Dify Workflow | Dify工作流 | 14_自动化_Workflow_低代码 | 145982 | 22959 | SSS 超顶流 | langgenius/dify |
| 9 | Open WebUI | Open WebUI | 09_本地模型_部署_推理 | 142000 | 20500 | SSS 超顶流 | open-webui/open-webui |
| 10 | LangChain | LangChain | 08_Agent框架_RAG框架_开发库 | 139784 | 23183 | SSS 超顶流 | langchain-ai/langchain |
| 11 | ComfyUI | ComfyUI | 12_设计_图像_视频AI | 118000 | 13800 | SSS 超顶流 | Comfy-Org/ComfyUI |
| 12 | llama.cpp | llama.cpp | 09_本地模型_部署_推理 | 117000 | 19800 | SSS 超顶流 | ggml-org/llama.cpp |
| 13 | Gemini CLI | Gemini CLI | 07_AI编程工具_IDE_Agent | 105000 | 14100 | SSS 超顶流 | google-gemini/gemini-cli |
| 14 | Browser-use | Browser-use | 11_BrowserAgent_AI浏览器 | 99800 | 11100 | SS 顶流 | browser-use/browser-use |
| 15 | Puppeteer | Puppeteer | 11_BrowserAgent_AI浏览器 | 92000 | 9000 | SS 顶流 | puppeteer/puppeteer |
| 16 | n8n | n8n | 14_自动化_Workflow_低代码 | 90000 | 25000 | SS 顶流 | n8n-io/n8n |
| 17 | Supabase | Supabase | 22_开发_部署基础设施 | 88000 | 9600 | SS 顶流 | supabase/supabase |
| 18 | vLLM | vLLM | 09_本地模型_部署_推理 | 83400 | 18300 | SS 顶流 | vllm-project/vllm |
| 19 | OpenHands | OpenHands | 07_AI编程工具_IDE_Agent | 77900 | 9900 | SS 顶流 | All-Hands-AI/OpenHands |
| 20 | Playwright | Playwright | 11_BrowserAgent_AI浏览器 | 75000 | 4300 | SS 顶流 | microsoft/playwright |
| 21 | Elasticsearch | Elasticsearch | 10_RAG_知识库_向量数据库 | 72000 | 25000 | SS 顶流 | elastic/elasticsearch |
| 22 | RAGFlow | RAGFlow | 09_本地模型_部署_推理 | 70000 | 6500 | SS 顶流 | infiniflow/ragflow |
| 23 | Redis | Redis | 22_开发_部署基础设施 | 69000 | 24000 | SS 顶流 | redis/redis |
| 24 | Cline | Cline | 07_AI编程工具_IDE_Agent | 63600 | 6700 | SS 顶流 | cline/cline |
| 25 | AutoGen | AutoGen | 08_Agent框架_RAG框架_开发库 | 59100 | 8900 | SS 顶流 | microsoft/autogen |
| 26 | PrivateGPT | PrivateGPT | 09_本地模型_部署_推理 | 55000 | 7300 | SS 顶流 | zylon-ai/private-gpt |
| 27 | CrewAI | CrewAI | 08_Agent框架_RAG框架_开发库 | 54100 | 7600 | SS 顶流 | crewAIInc/crewAI |
| 28 | Git | Git | 22_开发_部署基础设施 | 54000 | 26000 | SS 顶流 | git/git |
| 29 | Flowise | Flowise | 08_Agent框架_RAG框架_开发库 | 53800 | 24600 | SS 顶流 | FlowiseAI/Flowise |
| 30 | Flowise | Flowise | 14_自动化_Workflow_低代码 | 53800 | 24600 | SS 顶流 | FlowiseAI/Flowise |
| 31 | PocketBase | PocketBase | 22_开发_部署基础设施 | 51000 | 2500 | SS 顶流 | pocketbase/pocketbase |
| 32 | Appwrite | Appwrite | 22_开发_部署基础设施 | 51000 | 4600 | SS 顶流 | appwrite/appwrite |
| 33 | LlamaIndex | LlamaIndex | 08_Agent框架_RAG框架_开发库 | 50200 | 7600 | SS 顶流 | run-llama/llama_index |
| 34 | AnythingLLM | AnythingLLM | 09_本地模型_部署_推理 | 50000 | 5200 | SS 顶流 | Mintplex-Labs/anything-llm |
| 35 | Meilisearch | Meilisearch | 10_RAG_知识库_向量数据库 | 50000 | 2000 | SS 顶流 | meilisearch/meilisearch |
| 36 | Aider | Aider | 07_AI编程工具_IDE_Agent | 46500 | 4600 | S 高热 | Aider-AI/aider |
| 37 | Text Generation WebUI | text-generation-webui | 09_本地模型_部署_推理 | 46000 | 5700 | S 高热 | oobabooga/text-generation-webui |
| 38 | Fooocus | Fooocus | 12_设计_图像_视频AI | 45000 | 5000 | S 高热 | lllyasviel/Fooocus |
| 39 | Prisma | Prisma | 22_开发_部署基础设施 | 45000 | 1600 | S 高热 | prisma/prisma |
| 40 | Milvus | Milvus | 10_RAG_知识库_向量数据库 | 44900 | 4100 | S 高热 | milvus-io/milvus |
| 41 | Airflow | Apache Airflow | 14_自动化_Workflow_低代码 | 40000 | 14000 | S 高热 | apache/airflow |
| 42 | FAISS | FAISS | 10_RAG_知识库_向量数据库 | 36000 | 4700 | S 高热 | facebookresearch/faiss |
| 43 | LangGraph | LangGraph | 08_Agent框架_RAG框架_开发库 | 35322 | 5924 | S 高热 | langchain-ai/langgraph |
| 44 | Docker Compose | Docker Compose | 22_开发_部署基础设施 | 35000 | 5400 | S 高热 | docker/compose |
| 45 | Continue | Continue | 07_AI编程工具_IDE_Agent | 34200 | 4800 | S 高热 | continuedev/continue |
| 46 | LocalAI | LocalAI | 09_本地模型_部署_推理 | 34000 | 2500 | S 高热 | mudler/LocalAI |
| 47 | Logseq | Logseq | 13_Obsidian_第二大脑_个人知识库 | 34000 | 1900 | S 高热 | logseq/logseq |
| 48 | Hugging Face Diffusers | Diffusers | 12_设计_图像_视频AI | 33900 | 7100 | S 高热 | huggingface/diffusers |
| 49 | Tabby | Tabby | 07_AI编程工具_IDE_Agent | 33600 | 1800 | S 高热 | TabbyML/tabby |
| 50 | Selenium | Selenium | 11_BrowserAgent_AI浏览器 | 33000 | 8000 | S 高热 | SeleniumHQ/selenium |
| 51 | Qdrant | Qdrant | 10_RAG_知识库_向量数据库 | 32500 | 2400 | S 高热 | qdrant/qdrant |
| 52 | LiteLLM | LiteLLM | 08_Agent框架_RAG框架_开发库 | 30000 | 4000 | S 高热 | BerriAI/litellm |
| 53 | Drizzle | Drizzle ORM | 22_开发_部署基础设施 | 30000 | 900 | S 高热 | drizzle-team/drizzle-orm |
| 54 | Chroma | Chroma | 10_RAG_知识库_向量数据库 | 28500 | 2300 | S 高热 | chroma-core/chroma |
| 55 | Semantic Kernel | Semantic Kernel | 08_Agent框架_RAG框架_开发库 | 28200 | 4700 | S 高热 | microsoft/semantic-kernel |
| 56 | DSPy | DSPy | 08_Agent框架_RAG框架_开发库 | 28000 | 2200 | S 高热 | stanfordnlp/dspy |
| 57 | InvokeAI | InvokeAI | 12_设计_图像_视频AI | 27000 | 3000 | S 高热 | invoke-ai/InvokeAI |
| 58 | Qwen Code | Qwen Code | 07_AI编程工具_IDE_Agent | 25400 | 2500 | S 高热 | QwenLM/qwen-code |
| 59 | ControlNet | ControlNet | 12_设计_图像_视频AI | 25000 | 3000 | S 高热 | lllyasviel/ControlNet |
| 60 | Roo Code | Roo Code | 07_AI编程工具_IDE_Agent | 24200 | 3300 | S 高热 | RooCodeInc/Roo-Code |
| 61 | Stagehand | Stagehand | 11_BrowserAgent_AI浏览器 | 23200 | 1600 | S 高热 | browserbase/stagehand |
| 62 | Haystack | Haystack | 08_Agent框架_RAG框架_开发库 | 23000 | 4200 | S 高热 | deepset-ai/haystack |
| 63 | Typesense | Typesense | 10_RAG_知识库_向量数据库 | 23000 | 1600 | S 高热 | typesense/typesense |
| 64 | GraphQL | GraphQL | 22_开发_部署基础设施 | 21000 | 2100 | S 高热 | graphql/graphql-js |
| 65 | Node-RED | Node-RED | 14_自动化_Workflow_低代码 | 20000 | 3400 | S 高热 | node-red/node-red |
| 66 | bolt.diy | bolt.diy | 07_AI编程工具_IDE_Agent | 19000 | 2300 | A 中高热 | stackblitz-labs/bolt.diy |
| 67 | MLX | MLX | 09_本地模型_部署_推理 | 19000 | 1100 | A 中高热 | ml-explore/mlx |
| 68 | Activepieces | Activepieces | 14_自动化_Workflow_低代码 | 18000 | 2200 | A 中高热 | activepieces/activepieces |
| 69 | Vercel AI SDK | Vercel AI SDK | 08_Agent框架_RAG框架_开发库 | 17000 | 2700 | A 中高热 | vercel/ai |
| 70 | ONNX Runtime | ONNX Runtime | 09_本地模型_部署_推理 | 17000 | 4000 | A 中高热 | microsoft/onnxruntime |
| 71 | Prefect | Prefect | 14_自动化_Workflow_低代码 | 17000 | 1700 | A 中高热 | PrefectHQ/prefect |
| 72 | PostgreSQL | PostgreSQL | 22_开发_部署基础设施 | 17000 | 5300 | A 中高热 | postgres/postgres |
| 73 | Weaviate | Weaviate | 10_RAG_知识库_向量数据库 | 16400 | 1300 | A 中高热 | weaviate/weaviate |
| 74 | pgvector | pgvector | 10_RAG_知识库_向量数据库 | 15000 | 700 | A 中高热 | pgvector/pgvector |
| 75 | ComfyUI Manager | ComfyUI Manager | 12_设计_图像_视频AI | 15000 | 1500 | A 中高热 | Comfy-Org/ComfyUI-Manager |
| 76 | Temporal | Temporal | 14_自动化_Workflow_低代码 | 15000 | 2000 | A 中高热 | temporalio/temporal |
| 77 | Omnivore | Omnivore | 13_Obsidian_第二大脑_个人知识库 | 14000 | 900 | A 中高热 | omnivore-app/omnivore |
| 78 | Mastra | Mastra | 08_Agent框架_RAG框架_开发库 | 12000 | 900 | A 中高热 | mastra-ai/mastra |
| 79 | OpenAI Agents SDK | OpenAI Agents SDK | 08_Agent框架_RAG框架_开发库 | 11000 | 1800 | A 中高热 | openai/openai-agents-python |
| 80 | Pydantic AI | Pydantic AI | 08_Agent框架_RAG框架_开发库 | 11000 | 900 | A 中高热 | pydantic/pydantic-ai |
| 81 | OpenSearch | OpenSearch | 10_RAG_知识库_向量数据库 | 11000 | 5000 | A 中高热 | opensearch-project/OpenSearch |
| 82 | Zotero | Zotero | 13_Obsidian_第二大脑_个人知识库 | 11000 | 800 | A 中高热 | zotero/zotero |
| 83 | TGI | Text Generation Inference | 09_本地模型_部署_推理 | 10000 | 1200 | A 中高热 | huggingface/text-generation-inference |
| 84 | TensorRT-LLM | TensorRT-LLM | 09_本地模型_部署_推理 | 10000 | 1400 | A 中高热 | NVIDIA/TensorRT-LLM |
| 85 | Google ADK | Google ADK | 08_Agent框架_RAG框架_开发库 | 8000 | 900 | B 垂直热 | google/adk-python |
| 86 | LanceDB | LanceDB | 10_RAG_知识库_向量数据库 | 8000 | 700 | B 垂直热 | lancedb/lancedb |
| 87 | Anytype | Anytype | 13_Obsidian_第二大脑_个人知识库 | 6000 | 500 | B 垂直热 | anyproto/anytype-ts |