# 10_RAG_知识库_向量数据库

- 词条数量：12
- 更新时间：2026-06-21
- 用法：先看表格总览，再在下方词条内记录教程、试用经验、接入步骤。

## 快速总览

| 原名 | 直译 | 常用中文名 | 类型 | 热度 | Stars | Forks | 开源 | 本地部署 | 适合Codex | 来源 |
|---|---|---|---|---|---:|---:|---|---|---|---|
| FAISS | Facebook AI相似度搜索 | FAISS | 开源项目/向量检索 | S 高热 | 36000 | 4700 | 是 | 是 | 是 | https://github.com/facebookresearch/faiss |
| Milvus | 品牌名 | Milvus | 开源项目/向量数据库 | S 高热 | 44900 | 4100 | 是 | 是 | 是 | https://github.com/milvus-io/milvus |
| Qdrant | 品牌名 | Qdrant | 开源项目/向量数据库 | S 高热 | 32500 | 2400 | 是 | 是 | 是 | https://github.com/qdrant/qdrant |
| Chroma | 色度 | Chroma | 开源项目/向量库 | S 高热 | 28500 | 2300 | 是 | 是 | 是 | https://github.com/chroma-core/chroma |
| Weaviate | 品牌名 | Weaviate | 开源项目/向量数据库 | A 中高热 | 16400 | 1300 | 是 | 是 | 是 | https://github.com/weaviate/weaviate |
| pgvector | Postgres向量 | pgvector | 开源项目/数据库扩展 | A 中高热 | 15000 | 700 | 是 | 是 | 是 | https://github.com/pgvector/pgvector |
| Pinecone | 松果 | Pinecone | 平台/向量数据库 |  |  |  | 否 | 否 | 是 | https://www.pinecone.io/ |
| LanceDB | Lance数据库 | LanceDB | 开源项目/向量数据库 | B 垂直热 | 8000 | 700 | 是 | 是 | 是 | https://github.com/lancedb/lancedb |
| Elasticsearch | 弹性搜索 | Elasticsearch | 开源项目/搜索引擎 | SS 顶流 | 72000 | 25000 | 是 | 是 | 是 | https://github.com/elastic/elasticsearch |
| OpenSearch | 开放搜索 | OpenSearch | 开源项目/搜索引擎 | A 中高热 | 11000 | 5000 | 是 | 是 | 是 | https://github.com/opensearch-project/OpenSearch |
| Meilisearch | Meili搜索 | Meilisearch | 开源项目/搜索引擎 | SS 顶流 | 50000 | 2000 | 是 | 是 | 是 | https://github.com/meilisearch/meilisearch |
| Typesense | 类型感知 | Typesense | 开源项目/搜索引擎 | S 高热 | 23000 | 1600 | 是 | 是 | 是 | https://github.com/typesense/typesense |

## 详细词条

## FAISS

> Meta开源高性能向量检索库。

| 字段 | 内容 |
|---|---|
| 原名 | FAISS |
| 直译 | Facebook AI相似度搜索 |
| 常用中文名 | FAISS |
| 类别 | 10_RAG_知识库_向量数据库 |
| 类型 | 开源项目/向量检索 |
| 能给AI起到什么帮助 | 为AI提供检索、知识库、语义搜索和依据化能力。 |
| 代表平台/官网 | https://github.com/facebookresearch/faiss |
| 代表GitHub仓库 | facebookresearch/faiss |
| GitHub Stars(约) | 36000 |
| Forks(约) | 4700 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | RAG,向量数据库,知识库,检索 |
| 风险/备注 | RAG质量取决于文档解析、切块、检索和重排，不只看数据库。 |
| 数据来源URL | https://github.com/facebookresearch/faiss |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Milvus

> 云原生向量数据库，适合大规模RAG。

| 字段 | 内容 |
|---|---|
| 原名 | Milvus |
| 直译 | 品牌名 |
| 常用中文名 | Milvus |
| 类别 | 10_RAG_知识库_向量数据库 |
| 类型 | 开源项目/向量数据库 |
| 能给AI起到什么帮助 | 为AI提供检索、知识库、语义搜索和依据化能力。 |
| 代表平台/官网 | https://github.com/milvus-io/milvus |
| 代表GitHub仓库 | milvus-io/milvus |
| GitHub Stars(约) | 44900 |
| Forks(约) | 4100 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | RAG,向量数据库,知识库,检索 |
| 风险/备注 | RAG质量取决于文档解析、切块、检索和重排，不只看数据库。 |
| 数据来源URL | https://github.com/milvus-io/milvus |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Qdrant

> Rust实现的向量数据库/搜索引擎。

| 字段 | 内容 |
|---|---|
| 原名 | Qdrant |
| 直译 | 品牌名 |
| 常用中文名 | Qdrant |
| 类别 | 10_RAG_知识库_向量数据库 |
| 类型 | 开源项目/向量数据库 |
| 能给AI起到什么帮助 | 为AI提供检索、知识库、语义搜索和依据化能力。 |
| 代表平台/官网 | https://github.com/qdrant/qdrant |
| 代表GitHub仓库 | qdrant/qdrant |
| GitHub Stars(约) | 32500 |
| Forks(约) | 2400 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | RAG,向量数据库,知识库,检索 |
| 风险/备注 | RAG质量取决于文档解析、切块、检索和重排，不只看数据库。 |
| 数据来源URL | https://github.com/qdrant/qdrant |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Chroma

> 轻量AI搜索基础设施，本地RAG常用。

| 字段 | 内容 |
|---|---|
| 原名 | Chroma |
| 直译 | 色度 |
| 常用中文名 | Chroma |
| 类别 | 10_RAG_知识库_向量数据库 |
| 类型 | 开源项目/向量库 |
| 能给AI起到什么帮助 | 为AI提供检索、知识库、语义搜索和依据化能力。 |
| 代表平台/官网 | https://github.com/chroma-core/chroma |
| 代表GitHub仓库 | chroma-core/chroma |
| GitHub Stars(约) | 28500 |
| Forks(约) | 2300 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | RAG,向量数据库,知识库,检索 |
| 风险/备注 | RAG质量取决于文档解析、切块、检索和重排，不只看数据库。 |
| 数据来源URL | https://github.com/chroma-core/chroma |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Weaviate

> 向量数据库，支持语义搜索和结构化过滤。

| 字段 | 内容 |
|---|---|
| 原名 | Weaviate |
| 直译 | 品牌名 |
| 常用中文名 | Weaviate |
| 类别 | 10_RAG_知识库_向量数据库 |
| 类型 | 开源项目/向量数据库 |
| 能给AI起到什么帮助 | 为AI提供检索、知识库、语义搜索和依据化能力。 |
| 代表平台/官网 | https://github.com/weaviate/weaviate |
| 代表GitHub仓库 | weaviate/weaviate |
| GitHub Stars(约) | 16400 |
| Forks(约) | 1300 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | RAG,向量数据库,知识库,检索 |
| 风险/备注 | RAG质量取决于文档解析、切块、检索和重排，不只看数据库。 |
| 数据来源URL | https://github.com/weaviate/weaviate |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## pgvector

> PostgreSQL向量扩展。

| 字段 | 内容 |
|---|---|
| 原名 | pgvector |
| 直译 | Postgres向量 |
| 常用中文名 | pgvector |
| 类别 | 10_RAG_知识库_向量数据库 |
| 类型 | 开源项目/数据库扩展 |
| 能给AI起到什么帮助 | 为AI提供检索、知识库、语义搜索和依据化能力。 |
| 代表平台/官网 | https://github.com/pgvector/pgvector |
| 代表GitHub仓库 | pgvector/pgvector |
| GitHub Stars(约) | 15000 |
| Forks(约) | 700 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | RAG,向量数据库,知识库,检索 |
| 风险/备注 | RAG质量取决于文档解析、切块、检索和重排，不只看数据库。 |
| 数据来源URL | https://github.com/pgvector/pgvector |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Pinecone

> 托管向量数据库平台。

| 字段 | 内容 |
|---|---|
| 原名 | Pinecone |
| 直译 | 松果 |
| 常用中文名 | Pinecone |
| 类别 | 10_RAG_知识库_向量数据库 |
| 类型 | 平台/向量数据库 |
| 能给AI起到什么帮助 | 为AI提供检索、知识库、语义搜索和依据化能力。 |
| 代表平台/官网 | https://www.pinecone.io/ |
| 是否开源 | 否 |
| 是否适合本地部署 | 否 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | RAG,向量数据库,知识库,检索 |
| 风险/备注 | RAG质量取决于文档解析、切块、检索和重排，不只看数据库。 |
| 数据来源URL | https://www.pinecone.io/ |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## LanceDB

> 向量数据库/多模态数据湖方向。

| 字段 | 内容 |
|---|---|
| 原名 | LanceDB |
| 直译 | Lance数据库 |
| 常用中文名 | LanceDB |
| 类别 | 10_RAG_知识库_向量数据库 |
| 类型 | 开源项目/向量数据库 |
| 能给AI起到什么帮助 | 为AI提供检索、知识库、语义搜索和依据化能力。 |
| 代表平台/官网 | https://github.com/lancedb/lancedb |
| 代表GitHub仓库 | lancedb/lancedb |
| GitHub Stars(约) | 8000 |
| Forks(约) | 700 |
| 热度等级 | B 垂直热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | RAG,向量数据库,知识库,检索 |
| 风险/备注 | RAG质量取决于文档解析、切块、检索和重排，不只看数据库。 |
| 数据来源URL | https://github.com/lancedb/lancedb |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Elasticsearch

> 搜索引擎，支持关键词/混合搜索。

| 字段 | 内容 |
|---|---|
| 原名 | Elasticsearch |
| 直译 | 弹性搜索 |
| 常用中文名 | Elasticsearch |
| 类别 | 10_RAG_知识库_向量数据库 |
| 类型 | 开源项目/搜索引擎 |
| 能给AI起到什么帮助 | 为AI提供检索、知识库、语义搜索和依据化能力。 |
| 代表平台/官网 | https://github.com/elastic/elasticsearch |
| 代表GitHub仓库 | elastic/elasticsearch |
| GitHub Stars(约) | 72000 |
| Forks(约) | 25000 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | RAG,向量数据库,知识库,检索 |
| 风险/备注 | RAG质量取决于文档解析、切块、检索和重排，不只看数据库。 |
| 数据来源URL | https://github.com/elastic/elasticsearch |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## OpenSearch

> 开源搜索和分析引擎。

| 字段 | 内容 |
|---|---|
| 原名 | OpenSearch |
| 直译 | 开放搜索 |
| 常用中文名 | OpenSearch |
| 类别 | 10_RAG_知识库_向量数据库 |
| 类型 | 开源项目/搜索引擎 |
| 能给AI起到什么帮助 | 为AI提供检索、知识库、语义搜索和依据化能力。 |
| 代表平台/官网 | https://github.com/opensearch-project/OpenSearch |
| 代表GitHub仓库 | opensearch-project/OpenSearch |
| GitHub Stars(约) | 11000 |
| Forks(约) | 5000 |
| 热度等级 | A 中高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | RAG,向量数据库,知识库,检索 |
| 风险/备注 | RAG质量取决于文档解析、切块、检索和重排，不只看数据库。 |
| 数据来源URL | https://github.com/opensearch-project/OpenSearch |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Meilisearch

> 轻量全文搜索引擎。

| 字段 | 内容 |
|---|---|
| 原名 | Meilisearch |
| 直译 | Meili搜索 |
| 常用中文名 | Meilisearch |
| 类别 | 10_RAG_知识库_向量数据库 |
| 类型 | 开源项目/搜索引擎 |
| 能给AI起到什么帮助 | 为AI提供检索、知识库、语义搜索和依据化能力。 |
| 代表平台/官网 | https://github.com/meilisearch/meilisearch |
| 代表GitHub仓库 | meilisearch/meilisearch |
| GitHub Stars(约) | 50000 |
| Forks(约) | 2000 |
| 热度等级 | SS 顶流 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | RAG,向量数据库,知识库,检索 |
| 风险/备注 | RAG质量取决于文档解析、切块、检索和重排，不只看数据库。 |
| 数据来源URL | https://github.com/meilisearch/meilisearch |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：

## Typesense

> 快速容错搜索引擎。

| 字段 | 内容 |
|---|---|
| 原名 | Typesense |
| 直译 | 类型感知 |
| 常用中文名 | Typesense |
| 类别 | 10_RAG_知识库_向量数据库 |
| 类型 | 开源项目/搜索引擎 |
| 能给AI起到什么帮助 | 为AI提供检索、知识库、语义搜索和依据化能力。 |
| 代表平台/官网 | https://github.com/typesense/typesense |
| 代表GitHub仓库 | typesense/typesense |
| GitHub Stars(约) | 23000 |
| Forks(约) | 1600 |
| 热度等级 | S 高热 |
| 是否开源 | 是 |
| 是否适合本地部署 | 是 |
| 适合Codex | 是 |
| 适合Claude Code | 是 |
| 适合Cursor | 是 |
| 适合商业项目 | 是 |
| 关键词标签 | RAG,向量数据库,知识库,检索 |
| 风险/备注 | RAG质量取决于文档解析、切块、检索和重排，不只看数据库。 |
| 数据来源URL | https://github.com/typesense/typesense |
| 数据状态 | GitHub采集/约数 |
| 更新时间 | 2026-06-21 |

### 使用记录
- 适合场景：
- 试用结论：
- 接入方式：
- 相关项目：
- 后续补充：
